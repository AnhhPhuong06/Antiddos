#!/usr/bin/env python3
"""Read-only loopback dashboard. No third-party packages or remote assets."""
import argparse
import json
import pathlib
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ASSETS = pathlib.Path(__file__).with_name("dashboard")


def read_engine(path):
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(1)
        client.connect(path)
        client.sendall(b"stats json\n")
        chunks = bytearray()
        while len(chunks) <= 65536:
            chunk = client.recv(4096)
            if not chunk:
                break
            chunks.extend(chunk)
        if len(chunks) > 65536:
            raise ValueError("Oversized engine response")
        data = json.loads(chunks)
        if data.get("schema_version") != 1:
            raise ValueError("Unsupported engine version")
        return data


def read_kernel():
    binary = next((p for p in ("/usr/sbin/nft", "/sbin/nft") if pathlib.Path(p).is_file()), None)
    if not binary:
        return None
    # Query five counters only; dumping the entire table would include up to
    # hundreds of thousands of live per-IP meter elements under an attack.
    result = subprocess.run([binary, "-j", "list", "counters", "table", "inet", "antiddos"],
                            capture_output=True, timeout=1, check=True)
    counters = {}
    for item in json.loads(result.stdout)["nftables"]:
        counter = item.get("counter", {})
        if counter.get("table") == "antiddos" and counter.get("name"):
            counters[counter["name"]] = {k: counter.get(k, 0) for k in ("packets", "bytes")}
    return counters


class DashboardServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, settings):
        self.slots = threading.BoundedSemaphore(16)
        self.lock = threading.Lock()
        self.settings = settings
        self.latest = {"online": False, "demo": settings.demo, "services": [], "blocked": []}
        super().__init__(address, handler)

    def get_request(self):
        client, address = super().get_request()
        client.settimeout(3)
        return client, address

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def collect(self):
        started = time.monotonic()
        while True:
            try:
                if self.settings.demo:
                    elapsed = time.monotonic() - started
                    data = {"online": True, "demo": True, "dry_run": True, "firewall_healthy": False,
                            "capture_enabled": True, "observed_packets": int(elapsed * 8200),
                            "observed_bytes": int(elapsed * 8200 * 480), "observed_flagged": 0,
                            "capture_drops": 0, "table_overflows": 0, "ban_count": 0,
                            "kernel_counters": None, "services": [
                                {"id": 1, "name": "game-udp", "port": 27015, "protocol": "udp", "pps_limit": 50000, "risk": 0},
                                {"id": 2, "name": "api-tcp", "port": 443, "protocol": "tcp", "pps_limit": 20000, "risk": 0}], "blocked": []}
                else:
                    data = read_engine(self.settings.socket)
                    data.update(online=True, demo=False)
                    try:
                        data["kernel_counters"] = read_kernel()
                    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
                        data["kernel_counters"] = None
                data["sample_time"] = time.time()
            except (OSError, ValueError, KeyError):
                data = {"online": False, "demo": False, "services": [], "blocked": [], "sample_time": time.time()}
            with self.lock:
                self.latest = data
            time.sleep(1)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        hosts = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
        if self.headers.get("Host", "").lower() not in hosts:
            self.send_error(403)
            return
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in {"http://" + h for h in hosts}:
            self.send_error(403)
            return
        assets = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"), "/style.css": ("style.css", "text/css")}
        if self.path == "/api/status":
            with self.server.lock:
                payload = json.dumps(self.server.latest, ensure_ascii=False).encode("utf-8")
            content_type = "application/json"
        elif self.path in assets:
            filename, content_type = assets[self.path]
            payload = (ASSETS / filename).read_bytes()
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        self.send_error(405, "Read-only dashboard")

    def log_message(self, *_):
        pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--socket", default="/run/antiddos.sock")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--demo", action="store_true", help="Explicitly simulated data; never activates protection")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("port must be between 1024 and 65535")
    server = DashboardServer(("127.0.0.1", args.port), Handler, args)
    threading.Thread(target=server.collect, daemon=True).start()
    print(f"Dashboard: http://127.0.0.1:{args.port} ({'DEMO - simulated data' if args.demo else 'read-only'})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
