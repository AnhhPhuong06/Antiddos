# Outils et mesures

`run-local.sh` démarre le moteur avec un binaire et une configuration donnés.
Il ne génère aucun trafic. Les compteurs se lisent sur le socket Unix du moteur.

`test-linux.sh` compile le moteur et ses cinq suites C, lance les suites puis
vérifie la configuration et génère une politique nftables sans l'installer.

`dashboard.py` sert les fichiers de `dashboard/` sur le loopback, en lecture seule.
Voir le README principal pour son utilisation réelle ou le mode `--demo`.

Les tests d'intégration doivent se lancer dans un espace réseau jetable :
`sudo unshare -n env ANTIDDOS_TEST_NETNS=1 python3 tests/test_integration.py`.

Les essais fonctionnels ne constituent pas un benchmark de débit. Mesurer sur
le serveur cible les paquets livrés, bits/s, CPU, mémoire, pertes de capture,
compteurs nftables et latence avant d'annoncer une capacité de protection.
