#!/bin/sh
# Run a local, authorised benchmark against a capture interface. This script
# only reports counters; it does not generate traffic.
set -eu
BIN=${1:-./antiddos}
CFG=${2:-config/antiddos.conf}
exec "$BIN" "$CFG"
