"use strict";
const $ = (id) => document.getElementById(id);
const number = (value) => Number(value || 0).toLocaleString("fr-FR", {maximumFractionDigits: 0});
let previous = null, history = [];
function row(table, values) {
  const tr = document.createElement("tr");
  for (const value of values) { const td = document.createElement("td"); if (value instanceof Node) td.append(value); else td.textContent = value; tr.append(td); }
  table.append(tr);
}
function empty(table, message, columns) { const tr = document.createElement("tr"), td = document.createElement("td"); td.colSpan = columns; td.className = "empty"; td.textContent = message; tr.append(td); table.append(tr); }
function draw() {
  const canvas = $("chart"), ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth, height = canvas.clientHeight;
  canvas.width = width * ratio; canvas.height = height * ratio;
  const ctx = canvas.getContext("2d"); ctx.scale(ratio, ratio);
  const maximum = Math.max(100, ...history.map(x => x || 0)) * 1.15;
  ctx.font = "10px system-ui"; ctx.fillStyle = "#8ea0aa";
  for (let i = 0; i <= 3; i++) { const y = 10 + (height - 30) * i / 3; ctx.strokeStyle = "#26333b"; ctx.beginPath(); ctx.moveTo(46, y); ctx.lineTo(width, y); ctx.stroke(); ctx.fillText(number(maximum * (1 - i / 3)), 0, y + 4); }
  $("chart-empty").style.display = history.some(x => x !== null) ? "none" : "grid";
  if (history.length < 2) return;
  ctx.strokeStyle = "#6be0b4"; ctx.lineWidth = 2; ctx.beginPath(); let connected = false;
  history.forEach((value, i) => { if (value === null) { connected = false; return; } const x = 46 + (width - 46) * i / Math.max(89, history.length - 1), y = 10 + (height - 30) * (1 - value / maximum); if (connected) ctx.lineTo(x, y); else ctx.moveTo(x, y); connected = true; }); ctx.stroke();
}
function render(data) {
  const status = $("status"); status.className = "badge";
  if (!data.online) { status.textContent = "Moteur hors ligne"; status.classList.add("error"); }
  else if (data.demo) { status.textContent = "Démonstration"; status.classList.add("neutral"); }
  else if (data.dry_run) { status.textContent = "Mode observation"; status.classList.add("neutral"); }
  else if (!data.firewall_healthy) { status.textContent = "Erreur de synchronisation"; status.classList.add("error"); }
  else status.textContent = "Filtrage actif";
  $("notice").hidden = data.online && !data.demo && !data.dry_run && data.firewall_healthy;
  $("notice").textContent = !data.online ? "Le tableau de bord attend le moteur anti-DDoS. Les compteurs indisponibles sont affichés par un tiret." : data.demo ? "Démonstration : données simulées. Aucune protection n’est activée par cet affichage." : data.dry_run ? "Mode observation : le moteur ne modifie pas le pare-feu. Les paquets signalés ne sont pas des blocages réseau." : "La dernière mise à jour des bannissements a échoué. Les limites déjà installées restent dans le noyau.";
  const kernel = data.kernel_counters;
  const packets = kernel?.protected_input?.packets ?? data.observed_packets;
  const bytes = kernel?.protected_input?.bytes ?? data.observed_bytes;
  let pps = null, bps = null;
  if (data.online && previous && previous.online && previous.demo === data.demo && !!previous.kernel_counters === !!kernel) {
    const seconds = data.sample_time - previous.sample_time;
    const oldPackets = previous.kernel_counters?.protected_input?.packets ?? previous.observed_packets;
    const oldBytes = previous.kernel_counters?.protected_input?.bytes ?? previous.observed_bytes;
    if (seconds > 0 && packets >= oldPackets && bytes >= oldBytes) { pps = (packets - oldPackets) / seconds; bps = (bytes - oldBytes) * 8 / seconds; }
  }
  if (!previous || data.sample_time !== previous.sample_time) { history.push(pps); history = history.slice(-90); }
  $("bandwidth").textContent = bps === null ? "—" : (bps / 1e6).toLocaleString("fr-FR", {maximumFractionDigits: 1}) + " Mb/s";
  $("pps").textContent = pps === null ? "—" : number(pps);
  $("source").textContent = data.demo ? "Données simulées" : kernel ? "Compteurs du noyau" : "Capture du moteur C";
  $("bans").textContent = data.online ? number(data.ban_count) : "—";
  $("drops").textContent = data.online && kernel ? number((kernel.rate_dropped?.packets || 0) + (kernel.banned_dropped?.packets || 0) + (kernel.invalid_dropped?.packets || 0)) : "—";
  const services = $("services"), blocked = $("blocked"); services.replaceChildren(); blocked.replaceChildren();
  $("service-count").textContent = number(data.services?.length); $("ban-count").textContent = number(data.ban_count);
  for (const service of data.services || []) {
    const name = document.createElement("span"); name.textContent = service.name;
    const protocol = document.createElement("span"); protocol.className = "proto"; protocol.textContent = service.protocol; name.append(protocol);
    const state = document.createElement("span"); state.className = "state" + (service.risk ? " warning" : ""); state.textContent = ["Normal", "À surveiller", "Risque élevé", "Attaque"][service.risk] || "Inconnu";
    row(services, [name, String(service.port), number(service.pps_limit) + " p/s", state]);
  }
  if (!data.services?.length) empty(services, "Configuration du moteur indisponible", 4);
  for (const ban of data.blocked || []) { const service = data.services?.find(x => x.id === ban.service_id); row(blocked, [ban.ip, service ? String(service.port) + " / " + service.protocol.toUpperCase() : "Tous · manuel", ban.permanent ? "Manuel" : number(ban.remaining_seconds) + " s"]); }
  if (!data.blocked?.length) empty(blocked, data.online ? "Aucun bannissement actif" : "En attente du moteur", 3);
  $("health").textContent = !data.online ? "Moteur injoignable" : `${data.capture_enabled ? "Capture active" : "Capture inactive · nouveaux bans automatiques indisponibles"} · Pertes : ${number(data.capture_drops)} paquets · Table saturée : ${number(data.table_overflows)} événements`;
  $("updated").textContent = data.online ? "Dernier relevé · " + new Date(data.sample_time * 1000).toLocaleTimeString("fr-FR") : "Actualisation chaque seconde";
  previous = data; draw();
}
async function update() { try { const response = await fetch("/api/status", {cache: "no-store", signal: AbortSignal.timeout(3000)}); if (!response.ok) throw Error("HTTP"); render(await response.json()); } catch { render({online: false, services: [], blocked: [], sample_time: Date.now() / 1000}); } }
window.addEventListener("resize", draw); update(); setInterval(update, 1000);
