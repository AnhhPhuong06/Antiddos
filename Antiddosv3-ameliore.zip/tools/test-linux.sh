#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build
CC=${CC:-cc}
FLAGS='-O2 -g -UNDEBUG -std=c11 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -fstack-protector-strong -D_FORTIFY_SOURCE=2 -D_POSIX_C_SOURCE=200809L -D_GNU_SOURCE -Iinclude -Isrc'
mkdir -p build/tmp
export TMPDIR="$(pwd)/build/tmp"
$CC $FLAGS src/*.c -pthread -o build/antiddos
$CC $FLAGS tests/test_core.c src/packet.c src/limiter.c src/reputation.c src/detector.c -pthread -o build/test_core
$CC $FLAGS tests/test_config.c src/config.c -o build/test_config
$CC $FLAGS tests/test_firewall.c src/firewall.c src/config.c -pthread -o build/test_firewall
$CC $FLAGS tests/test_connection.c src/connection.c -pthread -o build/test_connection
$CC $FLAGS tests/test_management.c src/management.c src/network.c -pthread -o build/test_management
for test in build/test_core build/test_config build/test_firewall build/test_connection build/test_management; do "$test"; done
build/antiddos --check-config config/antiddos.conf
build/antiddos --print-firewall config/antiddos.conf > build/antiddos-policy.nft
