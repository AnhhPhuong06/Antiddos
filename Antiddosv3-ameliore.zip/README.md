# AntiDDoS — version améliorée

Agent C11 pour protéger les services d'un serveur **Linux** avec `nftables`.
La structure d'origine reste conservée : `include/`, `src/`, `config/`,
`scripts/`, `systemd/`, `tests/` et `tools/`.
Les profils fournis conservent **UDP 27015** pour le jeu et **TCP 443** pour l'API.

Le blocage des paquets se fait maintenant dans le noyau. Le programme C observe
le trafic, recherche des excès persistants par IP et ajoute des bannissements
temporaires limités au service concerné. Un tableau de bord local est fourni.

## Ce qui change

- Limites réelles de paquets/s, bits/s, SYN, UDP et ICMP via `nftables`.
- Limites par service et par IP, en IPv4 et IPv6 ; limites de connexions TCP
  globales, par service et par IP.
- Bannissements automatiques par couple service/IP : bloquer une IP sur le jeu
  ne bloque pas son accès à l'API. Au moins deux fenêtres d'une seconde contenant
  des violations sont nécessaires ; 100 paquets cumulés ne déclenchent plus un ban.
- Réception par lots avec `recvmmsg`, buffers réutilisés et budget par événement.
  Les commandes de gestion continuent à être traitées pendant le trafic.
- Compteurs de connexions par IP et service sans parcours complet de la table
  à chaque paquet ; recherches limitées à 64 sondages, nettoyage par petits lots.
- Mise à jour atomique des listes du pare-feu par un thread séparé, sans commande
  shell et sans lancer un processus pour chaque IP dans le chemin des paquets.
- Configuration mieux validée, profils qui se chevauchent refusés, IPC prenant
  en charge les lectures/écritures partielles et les clients trop lents.
- Tableau de bord en lecture seule, lié à `127.0.0.1`, sans dépendance Python
  externe ni ressource distante. Les vrais paquets bloqués viennent des compteurs
  du noyau ; les paquets signalés par l'observateur sont une autre mesure.
- L'installation conserve un fichier de configuration déjà présent.

## Architecture et portée

```text
Interface réseau -> pile Linux / nftables -> service TCP ou UDP
                   | limites et bannissements réels
                   |
                   +-> observation AF_PACKET -> parsing -> métriques/réputation
                                                         -> mise à jour des bans
                                                         -> socket Unix local
                                                            -> tableau de bord
```

`AF_PACKET` reste une capture passive. Perdre un paquet de capture ou le signaler
comme suspect n'est pas un blocage réseau. Les règles s'appliquent au hook `input`
du serveur, aux protocoles/adresses/ports configurés et à `capture_interface`
si elle est renseignée. Cette version n'est pas un filtre de trafic transféré
pour un routeur. Les adresses `0.0.0.0` et `::` signifient ici toutes les adresses,
IPv4 et IPv6. Les autres adresses de service ciblent une destination précise.

L'agent ne déchiffre pas HTTPS et n'analyse pas les requêtes HTTP ni les sessions
du jeu. Les limites TCP reposent sur conntrack. Un trafic volumétrique qui sature
la connexion Internet doit être filtré en amont par l'hébergeur/opérateur.
Le débit maximal, le coût conntrack et les faux positifs doivent être mesurés
sur le serveur cible : aucun débit garanti en Gbit/s n'est annoncé.

## Compiler et vérifier

Prérequis : Linux, compilateur C11, pthread, outils de compilation et `nftables`.
Python 3 est facultatif pour le tableau de bord et les essais d'intégration.
Le moteur utilise `epoll`, `timerfd`, `AF_PACKET` et `recvmmsg` ; il ne s'exécute
pas directement sous Windows.

L'archive livrée contient aussi `antiddos`, un binaire **Linux x86-64** compilé
statiquement et testé. Les sources restent fournies pour le recompiler sur
une autre architecture. Après extraction sous Linux, si nécessaire :
`chmod +x antiddos`.

```sh
make release
make test
./antiddos --check-config config/antiddos.conf
./antiddos --print-firewall config/antiddos.conf > /tmp/antiddos-policy.nft
sudo nft -c -f /tmp/antiddos-policy.nft  # vérifie sans installer les règles
```

Autres options : `make debug`, `make sanitize` (ASan/UBSan si disponibles),
ou `cmake -S . -B build && cmake --build build && ctest --test-dir build`.
`sh tools/test-linux.sh` réalise une compilation stricte avec `-Werror`, lance
les cinq suites C et génère `build/antiddos-policy.nft`.

## Configuration

Le fichier fourni reste en observation : `enable_firewall=0` et interface vide.
Les ports des services sont définis par `service.listen_port`, pas par le port
du tableau de bord. Pour protéger le serveur, renseigner son interface réelle
dans `capture_interface` puis utiliser `enable_firewall=1`.

| Paramètre | Valeur fournie | Rôle |
|---|---:|---|
| `pps_limit` | 100000 | Paquets/s partagés entre services protégés |
| `bps_limit` | 1000000000 | Bits/s partagés entre services protégés |
| `ip_pps_limit` | 5000 | Paquets/s par IP et service |
| `ip_bps_limit` | 50000000 | Bits/s par IP et service |
| `ip_syn_limit` | 100 | SYN/s par IP et service TCP |
| `rate_burst_packets` | 256 | Tolérance des rafales de paquets/SYN |
| `max_connections` | 100000 | Plafond global de connexions TCP suivies |
| `max_connections_per_ip` | 256 | Plafond TCP par IP et service |
| `temporary_ban_seconds` | 60 | Durée des bannissements automatiques |
| `max_ip_entries` | 100000 | Capacité bornée de réputation et des mètres IP |
| `capture_batch_packets` | 256 | Travail maximal de capture par événement |

Les limites `service.pps_limit`, `service.bps_limit` et
`service.connection_limit` restent propres à chaque profil. La limite de
connexions concerne TCP ; le champ UDP est conservé pour la compatibilité.
Les limites nftables sont des seaux à jetons avec rafales, et non un découpage
strict de chaque seconde. Les rafales en octets valent une seconde du débit
configuré, avec un minimum de 65536 octets. Les mètres IP expirent après 60 s
d'inactivité et ont une capacité maximale explicite.

Les seuils fournis sont des valeurs de départ, pas un réglage adapté à tous les
jeux/API. Un NAT partagé, un proxy ou un téléchargement légitime peut justifier
de les relever. `worker_threads=1` correspond à l'observateur actuel ; le thread
de synchronisation nftables est distinct. Les autres valeurs sont refusées.
`management_poll_ms` reste accepté pour la compatibilité ; l'IPC est piloté
par epoll avec expiration des clients, pas par une boucle de polling périodique.

## Installer sur le serveur Linux

```sh
sudo sh scripts/install.sh
sudoedit /etc/antiddos/antiddos.conf
/usr/local/sbin/antiddos --check-config /etc/antiddos/antiddos.conf
sudo systemctl daemon-reload
sudo systemctl enable --now antiddos.service
sudo journalctl -u antiddos.service -f
```

Le programme installe lui-même sa table `inet antiddos` quand le filtrage est
activé. Il remplace uniquement cette table, de façon atomique, au démarrage.
Il conserve les autres tables du pare-feu. `scripts/nftables-setup.nft` est un
exemple généré depuis la configuration fournie ; régénérer les règles avec
`--print-firewall` après toute modification de ports ou de seuils.

Un échec d'installation du pare-feu fait échouer le démarrage. Une perte de
capture laisse les limites du noyau actives mais empêche une observation fiable
et les nouveaux bans automatiques ; le tableau de bord indique l'état de capture.
La dernière synchronisation réussie/échouée apparaît dans `firewall_healthy`.

**Arrêter le processus conserve les limites déjà installées dans le noyau.**
Les bans temporaires expirent. Pour désactiver complètement cette protection :

```sh
sudo systemctl stop antiddos.service
sudo nft delete table inet antiddos
```

Passer à `enable_firewall=0` ne supprime pas une table précédemment installée.
Les listes manuelles sont en mémoire ; elles doivent être réappliquées après
un redémarrage. Les intégrer à une configuration persistante est un travail
supplémentaire, pas une propriété annoncée de cette version.

## Gestion locale

Le socket Unix `/run/antiddos.sock` est créé en mode `0600`. Exemples avec `socat` :

```sh
printf 'stats json\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
printf 'list blocked\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
printf 'blacklist add 203.0.113.7\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
printf 'blacklist remove 203.0.113.7\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
printf 'whitelist add 203.0.113.8\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
printf 'flush\n' | sudo socat - UNIX-CONNECT:/run/antiddos.sock
```

`blacklist` est une décision manuelle globale sur l'hôte, sans expiration.
`whitelist` retire les bans de cette IP et exempte son trafic des limites de
cette table ; elle ne désactive pas les autres pare-feu du serveur. Ajouter à
l'une de ces listes retire l'IP de l'autre. `flush` retire les bans temporaires
et garde les politiques manuelles. Les changements sont mis en file puis
appliqués par le thread de pare-feu. `reload` demande un redémarrage validé,
sans prétendre recharger les seuils à chaud.

## Tableau de bord

```sh
sudo python3 tools/dashboard.py --socket /run/antiddos.sock
```

Ouvrir `http://127.0.0.1:8765/`. Pour un serveur distant, utiliser un tunnel SSH :
`ssh -L 8765:127.0.0.1:8765 utilisateur@serveur`, puis la même adresse locale.
Le port **8765 est uniquement celui de l'affichage** ; 27015 et 443 restent
inchangés. Les compteurs du noyau sont interrogés seuls une fois par seconde,
sans exporter les grandes tables de mètres IP. Sans accès au moteur/noyau,
l'interface indique explicitement les données indisponibles.

Pour prévisualiser sous Windows sans moteur Linux :

```powershell
python tools/dashboard.py --demo
```

Le bandeau « Démonstration » signifie que les données sont simulées et que
l'affichage n'active aucune protection.

## Vérifications réalisées

Validation dans un espace réseau Linux jetable, séparé du réseau de la machine,
avec noyau WSL 6.6.87.2 et nftables 1.1.5 :

- Compilation C11 stricte et cinq suites C réussies.
- Validation des règles avec `nft -c` et filtrage réel de rafales UDP.
- Filtrage réel de rafales UDP et bannissement ciblé également vérifiés en IPv6.
- Ban ciblé : UDP 27015 bloqué, TCP 443 accessible depuis la même IP.
- Deux connexions TCP autorisées avec plafond IP à deux, troisième refusée,
  autre IP autorisée.
- Liste noire permanente, passage en liste blanche et retrait de la liste noire
  sans supprimer la liste blanche.
- Ban automatique ciblé après des excès répétés ; réponses IPC pendant le trafic.
- Tests HTTP : hôtes/origines étrangers refusés, accès aux fichiers hors des
  ressources prévues refusé, écritures HTTP refusées.
- Tableau de bord vérifié dans le navigateur, sans erreur JavaScript observée.
- Suite du cœur exécutée également avec UndefinedBehaviorSanitizer.

Ces essais valident le comportement, pas un débit de production maximal.
Pour reproduire le test d'intégration sur Linux équipé de Python, nftables et ip :

```sh
sh tools/test-linux.sh
python3 tests/test_dashboard.py
sudo unshare -n env ANTIDDOS_TEST_NETNS=1 python3 tests/test_integration.py
```

Le test refuse l'espace réseau principal quand `/proc` est disponible. Il
utilise seulement le loopback et arrête son processus à la fin. Pour mesurer
un débit représentatif, utiliser le matériel cible et relever le débit livré,
les compteurs nftables, les pertes de capture, le CPU, la mémoire et la latence.
