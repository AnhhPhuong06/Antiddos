#ifndef ANTIDDOS_CONNECTION_H
#define ANTIDDOS_CONNECTION_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint8_t address[16];
    uint8_t address_len;
    uint32_t service_id;
    uint16_t src_port;
    uint16_t dst_port;
    uint8_t protocol;
    uint64_t accepted_ns;
    uint64_t last_seen_ns;
    uint32_t state;
} connection_key_t;

typedef struct connection_slot connection_slot_t;
typedef struct connection_ip_slot connection_ip_slot_t;
typedef struct {
    connection_slot_t *slots;
    connection_ip_slot_t *ip_slots;
    size_t capacity, size, max_entries, cleanup_cursor;
    size_t service_counts[33];
    uint64_t idle_timeout_ns;
    void *lock;
} connection_table_t;

int connection_init(connection_table_t *table, size_t capacity, uint64_t idle_timeout_ns);
void connection_destroy(connection_table_t *table);
int connection_open(connection_table_t *table, const connection_key_t *key, uint64_t now_ns);
int connection_touch(connection_table_t *table, const connection_key_t *key, uint64_t now_ns);
int connection_close(connection_table_t *table, const connection_key_t *key);
size_t connection_cleanup(connection_table_t *table, uint64_t now_ns, size_t budget);
size_t connection_count(const connection_table_t *table);
size_t connection_count_service(const connection_table_t *table, uint32_t service_id);
size_t connection_count_ip(const connection_table_t *table, const uint8_t *address,
                           uint8_t address_len, uint32_t service_id);

#endif
