#ifndef ANTIDDOS_PUBLIC_NETWORK_WRAPPER_H
#define ANTIDDOS_PUBLIC_NETWORK_WRAPPER_H
#include "../src/network.h"
#endif
