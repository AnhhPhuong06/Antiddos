#ifndef ANTIDDOS_LIMITER_H
#define ANTIDDOS_LIMITER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <pthread.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    LIMIT_KEY_GLOBAL = 0,
    LIMIT_KEY_IP,
    LIMIT_KEY_SUBNET,
    LIMIT_KEY_PORT,
    LIMIT_KEY_SERVICE,
    LIMIT_KEY_PROTOCOL
} limiter_key_type_t;

typedef struct {
    limiter_key_type_t type;
    uint8_t bytes[16];
    uint8_t len;
    uint8_t prefix_len;
    uint16_t port;
    uint32_t service;
    uint8_t protocol;
} limiter_key_t;

typedef struct {
    double rate;              /* tokens per second */
    double burst;             /* maximum bucket size */
    size_t capacity;          /* fixed number of key buckets */
    uint64_t idle_timeout_ns; /* zero disables expiry */
} limiter_config_t;

typedef struct limiter_bucket limiter_bucket_t;
typedef struct {
    limiter_bucket_t *buckets;
    size_t capacity;
    size_t size, cleanup_cursor;
    double rate;
    double burst;
    uint64_t idle_timeout_ns;
    pthread_mutex_t lock;
    bool lock_initialized;
} limiter_t;

int limiter_init(limiter_t *limiter, const limiter_config_t *config);
void limiter_destroy(limiter_t *limiter);
void limiter_key_global(limiter_key_t *key);
void limiter_key_ip(limiter_key_t *key, const uint8_t *addr, uint8_t addr_len);
void limiter_key_subnet(limiter_key_t *key, const uint8_t *addr, uint8_t addr_len,
                        uint8_t prefix_len);
void limiter_key_port(limiter_key_t *key, uint16_t port);
void limiter_key_service(limiter_key_t *key, uint32_t service_id);
void limiter_key_protocol(limiter_key_t *key, uint8_t protocol);

/* Consume amount tokens at now_ns. Returns true when allowed. */
bool limiter_allow(limiter_t *limiter, const limiter_key_t *key,
                   double amount, uint64_t now_ns);
/* Remove stale entries and return number removed. */
size_t limiter_cleanup(limiter_t *limiter, uint64_t now_ns);
size_t limiter_size(const limiter_t *limiter);

#ifdef __cplusplus
}
#endif
#endif
