#ifndef ANTIDDOS_REPUTATION_H
#define ANTIDDOS_REPUTATION_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { REPUTATION_CLEAN = 0, REPUTATION_SUSPECT,
               REPUTATION_GREYLIST, REPUTATION_BLOCKED } reputation_state_t;

typedef struct {
    uint8_t address[16];
    uint8_t address_len;
    uint32_t service_id;
} reputation_key_t;

typedef struct {
    reputation_key_t key;
    reputation_state_t state;
    uint32_t score;
    uint64_t packets;
    uint64_t bytes;
    uint64_t connections;
    uint64_t window_start_ns;
    uint64_t window_packets, window_bytes, window_syn;
    bool window_violation;
    uint32_t violations;
    uint64_t first_seen_ns;
    uint64_t last_seen_ns;
    uint64_t ban_until_ns;
    uint64_t last_decay_ns;
    bool whitelist;
    bool trusted;
    bool blacklist;
    bool permanent_ban;
} reputation_entry_t;

typedef struct {
    size_t capacity;
    uint64_t idle_ttl_ns;
    uint64_t score_decay_ns;
    uint32_t suspicious_threshold;
    uint32_t greylist_threshold;
    uint32_t block_threshold;
    uint64_t initial_ban_ns;
    uint64_t max_ban_ns;
    uint32_t minimum_violations;
} reputation_config_t;

typedef struct reputation_slot reputation_slot_t;
/* Caller owns synchronization: use one table per worker. No allocation occurs
 * after init. Entry pointers remain valid until cleanup/destroy. */
typedef struct {
    reputation_slot_t *slots;
    reputation_config_t config;
    size_t size;
    size_t cleanup_cursor;
    uint64_t hash_seed;
} reputation_table_t;

int reputation_init(reputation_table_t *table, const reputation_config_t *config);
void reputation_destroy(reputation_table_t *table);
void reputation_key(reputation_key_t *key, uint32_t service_id,
                    const uint8_t *address, uint8_t address_len);
reputation_entry_t *reputation_get(reputation_table_t *table,
                                   const reputation_key_t *key,
                                   uint64_t now_ns, bool create);
void reputation_observe(reputation_entry_t *entry, uint64_t bytes,
                        bool new_connection, uint64_t now_ns);
void reputation_observe_packet(reputation_entry_t *entry, uint64_t bytes,
                               bool new_connection, bool syn, uint64_t now_ns);
/* One call records aggregated evidence, not an individual packet anomaly.
 * Configured minimum_violations prevents one event from creating a ban. */
void reputation_violate(reputation_table_t *table, reputation_entry_t *entry,
                        uint32_t score_delta, uint64_t now_ns);
void reputation_refresh(reputation_table_t *table, reputation_entry_t *entry,
                        uint64_t now_ns);
bool reputation_is_blocked(reputation_table_t *table,
                            reputation_entry_t *entry, uint64_t now_ns);
int reputation_set_policy(reputation_table_t *table, const reputation_key_t *key,
                          bool whitelist, bool trusted, bool blacklist,
                          uint64_t now_ns);
/* Bounded maintenance: inspect at most budget slots. */
size_t reputation_cleanup(reputation_table_t *table, uint64_t now_ns, size_t budget);
size_t reputation_size(const reputation_table_t *table);
const reputation_entry_t *reputation_at(const reputation_table_t *table, size_t index);
void reputation_flush(reputation_table_t *table, bool keep_policy);

#ifdef __cplusplus
}
#endif
#endif
