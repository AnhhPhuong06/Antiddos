#ifndef ANTIDDOS_PUBLIC_LOGGER_WRAPPER_H
#define ANTIDDOS_PUBLIC_LOGGER_WRAPPER_H
#include "../src/logger.h"
#endif
