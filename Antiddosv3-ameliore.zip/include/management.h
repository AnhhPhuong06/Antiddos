#ifndef ANTIDDOS_PUBLIC_MANAGEMENT_WRAPPER_H
#define ANTIDDOS_PUBLIC_MANAGEMENT_WRAPPER_H
#include "../src/management.h"
#endif
