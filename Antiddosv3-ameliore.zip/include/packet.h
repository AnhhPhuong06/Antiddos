#ifndef ANTIDDOS_PACKET_H
#define ANTIDDOS_PACKET_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    PACKET_OK = 0,
    PACKET_ERR_ARGUMENT = -1,
    PACKET_ERR_TRUNCATED = -2,
    PACKET_ERR_MALFORMED = -3,
    PACKET_ERR_UNSUPPORTED = -4
} packet_result_t;

typedef enum {
    PACKET_PROTO_UNKNOWN = 0,
    PACKET_PROTO_TCP = 6,
    PACKET_PROTO_UDP = 17,
    PACKET_PROTO_ICMP = 1,
    PACKET_PROTO_ICMPV6 = 58
} packet_protocol_t;

/* A validated, non-owning view into an Ethernet frame. Address fields are in
 * network byte order and are copied out of the input buffer. */
typedef struct {
    uint8_t src_addr[16];
    uint8_t dst_addr[16];
    uint8_t addr_len;              /* 4 for IPv4, 16 for IPv6 */
    uint16_t ethertype;
    uint8_t protocol;
    uint16_t src_port;
    uint16_t dst_port;
    uint8_t tcp_flags;
    uint16_t ip_header_len;
    uint16_t l4_header_len;
    size_t network_offset;
    size_t transport_offset;
    size_t payload_offset;
    size_t payload_len;
    size_t frame_len;
    bool ipv6;
    bool fragmented;
    bool malformed;
} packet_view_t;

/* Parse and validate one complete Ethernet frame. No pointers in packet_view
 * refer to the input after this function returns. */
packet_result_t packet_parse(const uint8_t *frame, size_t frame_len,
                             packet_view_t *out);

#ifdef __cplusplus
}
#endif
#endif
