#ifndef ANTIDDOS_UTILS_H
#define ANTIDDOS_UTILS_H

#include <stddef.h>
#include <stdint.h>

uint64_t antiddos_monotonic_ns(void);
uint64_t antiddos_saturating_add_u64(uint64_t left, uint64_t right);
int antiddos_copy_string(char *destination, size_t destination_size, const char *source);

#endif
