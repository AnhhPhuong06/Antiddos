#ifndef ANTIDDOS_PUBLIC_MONITOR_WRAPPER_H
#define ANTIDDOS_PUBLIC_MONITOR_WRAPPER_H
#include "../src/monitor.h"
#endif
