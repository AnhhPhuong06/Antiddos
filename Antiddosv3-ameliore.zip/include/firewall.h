#ifndef ANTIDDOS_PUBLIC_FIREWALL_WRAPPER_H
#define ANTIDDOS_PUBLIC_FIREWALL_WRAPPER_H
#include "../src/firewall.h"
#endif
