#ifndef ANTIDDOS_PUBLIC_CONFIG_WRAPPER_H
#define ANTIDDOS_PUBLIC_CONFIG_WRAPPER_H
#include "../src/config.h"
#endif
