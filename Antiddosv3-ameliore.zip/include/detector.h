#ifndef ANTIDDOS_DETECTOR_H
#define ANTIDDOS_DETECTOR_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "packet.h"

typedef enum {
    DETECTOR_NORMAL = 0,
    DETECTOR_SUSPICIOUS = 1,
    DETECTOR_HIGH_RISK = 2,
    DETECTOR_ATTACK = 3
} detector_level_t;

typedef struct {
    size_t max_services;
    uint64_t window_ns;
    uint64_t pps_limit, bps_limit, syn_limit, udp_limit, icmp_limit;
    uint32_t suspicious_threshold, attack_threshold;
} detector_config_t;

typedef struct {
    uint32_t service_id;
    uint64_t packets, bytes, connections, syn, ack, rst, fin, udp, icmp;
    uint64_t window_start_ns;
    uint32_t score;
    detector_level_t level;
} detector_metric_t;

typedef struct {
    uint32_t service_id;
    uint8_t protocol;
    uint8_t source[16];
    uint8_t source_len;
    uint16_t tcp_flags;
    uint64_t bytes;
    bool new_connection;
} detector_event_t;

typedef struct detector {
    detector_config_t config;
    detector_metric_t *services;
    size_t service_count;
    void *lock; /* private pthread mutex */
} detector_t;

int detector_init(detector_t *detector, const detector_config_t *config);
void detector_destroy(detector_t *detector);
detector_level_t detector_observe(detector_t *detector,
                                  const detector_event_t *event,
                                  uint64_t now_ns, uint32_t *score_out);
int detector_snapshot(const detector_t *detector, uint32_t service_id,
                      detector_metric_t *out);
void detector_reset(detector_t *detector);

#endif
