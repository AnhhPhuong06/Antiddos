#include "reputation.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/random.h>

#define REPUTATION_MAX_PROBES 64U
struct reputation_slot { reputation_entry_t entry; uint64_t hash; uint8_t state; };
static uint64_t saturating_add(uint64_t a, uint64_t b) { return b > UINT64_MAX - a ? UINT64_MAX : a + b; }
static bool valid_key(const reputation_key_t *k) { return k && (k->address_len == 4 || k->address_len == 16); }
static uint64_t mix64(uint64_t v) { v ^= v >> 30; v *= 0xbf58476d1ce4e5b9ULL; v ^= v >> 27; v *= 0x94d049bb133111ebULL; return v ^ (v >> 31); }
static uint64_t key_hash(const reputation_table_t *t, const reputation_key_t *k) {
    uint64_t h = t->hash_seed ^ k->service_id ^ ((uint64_t)k->address_len << 32);
    for (uint8_t i = 0; i < k->address_len; ++i) h = mix64(h ^ k->address[i]);
    return h;
}
static bool keys_equal(const reputation_key_t *a, const reputation_key_t *b) {
    return a->service_id == b->service_id && a->address_len == b->address_len &&
           memcmp(a->address, b->address, a->address_len) == 0;
}
static size_t probe_limit(const reputation_table_t *t) { return t->config.capacity < REPUTATION_MAX_PROBES ? t->config.capacity : REPUTATION_MAX_PROBES; }

int reputation_init(reputation_table_t *t, const reputation_config_t *c) {
    ssize_t n;
    if (!t || !c || c->capacity < 2 || c->capacity > SIZE_MAX / sizeof(reputation_slot_t) ||
        c->suspicious_threshold == 0 || c->greylist_threshold <= c->suspicious_threshold ||
        c->block_threshold <= c->greylist_threshold || c->minimum_violations == 0 ||
        c->initial_ban_ns == 0 || c->max_ban_ns < c->initial_ban_ns) return -1;
    memset(t, 0, sizeof(*t));
    do { n = getrandom(&t->hash_seed, sizeof(t->hash_seed), 0); } while (n < 0 && errno == EINTR);
    if (n != (ssize_t)sizeof(t->hash_seed)) return -1;
    t->slots = calloc(c->capacity, sizeof(*t->slots));
    if (!t->slots) return -1;
    t->config = *c; return 0;
}
void reputation_destroy(reputation_table_t *t) { if (t) { free(t->slots); memset(t, 0, sizeof(*t)); } }
void reputation_key(reputation_key_t *k, uint32_t service_id, const uint8_t *a, uint8_t n) {
    if (!k) return;
    memset(k, 0, sizeof(*k)); k->service_id = service_id;
    if (a && (n == 4 || n == 16)) { memcpy(k->address, a, n); k->address_len = n; }
}
reputation_entry_t *reputation_get(reputation_table_t *t, const reputation_key_t *k, uint64_t now_ns, bool create) {
    uint64_t h; size_t first_free = SIZE_MAX;
    if (!t || !t->slots || !valid_key(k)) return NULL;
    h = key_hash(t, k);
    for (size_t n = 0; n < probe_limit(t); ++n) {
        size_t idx = ((size_t)(h % t->config.capacity) + n) % t->config.capacity;
        reputation_slot_t *slot = &t->slots[idx];
        if (slot->state == 1 && slot->hash == h && keys_equal(&slot->entry.key, k)) return &slot->entry;
        if (slot->state != 1 && first_free == SIZE_MAX) first_free = idx;
        if (slot->state == 0) break;
    }
    if (!create || first_free == SIZE_MAX) return NULL;
    reputation_slot_t *slot = &t->slots[first_free];
    memset(slot, 0, sizeof(*slot)); slot->state = 1; slot->hash = h;
    slot->entry.key = *k; slot->entry.first_seen_ns = now_ns;
    slot->entry.last_seen_ns = now_ns; slot->entry.last_decay_ns = now_ns;
    ++t->size; return &slot->entry;
}
void reputation_observe_packet(reputation_entry_t *e, uint64_t bytes, bool new_connection, bool syn, uint64_t now_ns) {
    if (!e) return;
    if (e->window_packets == 0 || now_ns < e->window_start_ns ||
        now_ns - e->window_start_ns >= 1000000000ULL) {
        e->window_start_ns = now_ns;
        e->window_packets = e->window_bytes = e->window_syn = 0;
        e->window_violation = false;
    }
    e->window_packets = saturating_add(e->window_packets, 1);
    e->window_bytes = saturating_add(e->window_bytes, bytes);
    if (syn) e->window_syn = saturating_add(e->window_syn, 1);
    e->packets = saturating_add(e->packets, 1); e->bytes = saturating_add(e->bytes, bytes);
    if (new_connection) e->connections = saturating_add(e->connections, 1);
    if (now_ns > e->last_seen_ns) e->last_seen_ns = now_ns;
}
void reputation_observe(reputation_entry_t *e, uint64_t bytes, bool new_connection, uint64_t now_ns) {
    reputation_observe_packet(e, bytes, new_connection, false, now_ns);
}
void reputation_refresh(reputation_table_t *t, reputation_entry_t *e, uint64_t now_ns) {
    uint64_t periods;
    if (!t || !e) return;
    if (e->blacklist || e->permanent_ban) { e->state = REPUTATION_BLOCKED; return; }
    if (e->whitelist || e->trusted) { e->state = REPUTATION_CLEAN; e->ban_until_ns = 0; return; }
    if (t->config.score_decay_ns && now_ns >= e->last_decay_ns) {
        periods = (now_ns - e->last_decay_ns) / t->config.score_decay_ns;
        if (periods) { e->score = periods >= e->score ? 0 : e->score - (uint32_t)periods; e->last_decay_ns = now_ns; }
    }
    if (e->ban_until_ns && now_ns < e->ban_until_ns) { e->state = REPUTATION_BLOCKED; return; }
    if (e->ban_until_ns) { e->score = 0; e->violations = 0; }
    e->ban_until_ns = 0;
    if (e->score >= t->config.greylist_threshold) e->state = REPUTATION_GREYLIST;
    else if (e->score >= t->config.suspicious_threshold) e->state = REPUTATION_SUSPECT;
    else { e->state = REPUTATION_CLEAN; if (!e->score) e->violations = 0; }
}
void reputation_violate(reputation_table_t *t, reputation_entry_t *e, uint32_t delta, uint64_t now_ns) {
    uint64_t ban;
    if (!t || !e || e->whitelist || e->trusted) return;
    reputation_refresh(t, e, now_ns);
    e->score = delta > UINT32_MAX - e->score ? UINT32_MAX : e->score + delta;
    if (e->violations < UINT32_MAX) ++e->violations;
    if (e->score >= t->config.block_threshold && e->violations >= t->config.minimum_violations) {
        ban = t->config.initial_ban_ns;
        uint32_t exponent = e->violations - t->config.minimum_violations;
        if (exponent > 32) exponent = 32;
        while (exponent-- && ban < t->config.max_ban_ns) ban = ban > t->config.max_ban_ns / 2 ? t->config.max_ban_ns : ban * 2;
        if (ban > t->config.max_ban_ns) ban = t->config.max_ban_ns;
        e->ban_until_ns = saturating_add(now_ns, ban); e->state = REPUTATION_BLOCKED;
    } else reputation_refresh(t, e, now_ns);
}
bool reputation_is_blocked(reputation_table_t *t, reputation_entry_t *e, uint64_t now_ns) {
    if (!t || !e) return false;
    reputation_refresh(t, e, now_ns); return e->state == REPUTATION_BLOCKED;
}
int reputation_set_policy(reputation_table_t *t, const reputation_key_t *k, bool white, bool trusted, bool black, uint64_t now_ns) {
    if ((white || trusted) && black) return -1;
    reputation_entry_t *e = reputation_get(t, k, now_ns, true); if (!e) return -1;
    bool was_blacklisted = e->blacklist || e->permanent_ban;
    e->whitelist = white; e->trusted = trusted; e->blacklist = black;
    if (was_blacklisted && !black) { e->permanent_ban = false; e->score = 0; e->violations = 0; e->ban_until_ns = 0; }
    if (white || trusted) { e->score = 0; e->ban_until_ns = 0; }
    reputation_refresh(t, e, now_ns); return 0;
}
size_t reputation_cleanup(reputation_table_t *t, uint64_t now_ns, size_t budget) {
    size_t removed = 0;
    if (!t || !t->slots || budget == 0) return 0;
    if (budget > t->config.capacity) budget = t->config.capacity;
    for (size_t n = 0; n < budget; ++n) {
        reputation_slot_t *slot = &t->slots[t->cleanup_cursor];
        t->cleanup_cursor = (t->cleanup_cursor + 1U) % t->config.capacity;
        if (slot->state != 1) continue;
        reputation_entry_t *e = &slot->entry; reputation_refresh(t, e, now_ns);
        if (!e->whitelist && !e->trusted && !e->blacklist && !e->permanent_ban &&
            e->state != REPUTATION_BLOCKED && t->config.idle_ttl_ns && now_ns >= e->last_seen_ns &&
            now_ns - e->last_seen_ns >= t->config.idle_ttl_ns && e->violations == 0 && e->score == 0) {
            memset(&slot->entry, 0, sizeof(slot->entry)); slot->hash = 0; slot->state = 2;
            --t->size; ++removed;
        }
    }
    return removed;
}
size_t reputation_size(const reputation_table_t *t) { return t ? t->size : 0; }
const reputation_entry_t *reputation_at(const reputation_table_t *t, size_t idx) {
    if (!t || !t->slots || idx >= t->config.capacity || t->slots[idx].state != 1) return NULL;
    return &t->slots[idx].entry;
}
void reputation_flush(reputation_table_t *t, bool keep_policy) {
    if (!t || !t->slots) return;
    for (size_t i = 0; i < t->config.capacity; ++i) {
        reputation_slot_t *s = &t->slots[i];
        if (s->state != 1) continue;
        if (keep_policy && (s->entry.whitelist || s->entry.trusted || s->entry.blacklist || s->entry.permanent_ban)) continue;
        memset(&s->entry, 0, sizeof(s->entry)); s->hash = 0; s->state = 2;
    }
    t->size = 0;
    for (size_t i = 0; i < t->config.capacity; ++i) t->size += t->slots[i].state == 1 ? 1U : 0U;
}
