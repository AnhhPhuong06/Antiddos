#ifndef ANTIDDOS_NETWORK_H
#define ANTIDDOS_NETWORK_H

#include <signal.h>
#include <stddef.h>
#include <stdint.h>

typedef int (*antiddos_network_callback)(int fd, uint32_t events, void *user);

typedef struct {
    int epoll_fd;
    size_t max_events;
    volatile sig_atomic_t stop;
    void *events;
} antiddos_network_t;

int antiddos_network_init(antiddos_network_t *net, size_t max_events);
void antiddos_network_close(antiddos_network_t *net);
int antiddos_network_set_nonblocking(int fd);
/* Opens a passive AF_PACKET observer. CAP_NET_RAW is required at runtime. */
int antiddos_network_open_packet(antiddos_network_t *net, const char *ifname, uint16_t ethertype);
int antiddos_network_add(antiddos_network_t *net, int fd, uint32_t events);
int antiddos_network_modify(antiddos_network_t *net, int fd, uint32_t events);
int antiddos_network_remove(antiddos_network_t *net, int fd);
int antiddos_network_run(antiddos_network_t *net, int timeout_ms,
                         antiddos_network_callback callback, void *user);
void antiddos_network_stop(antiddos_network_t *net);
int antiddos_network_install_signals(antiddos_network_t *net);
/* Open a bounded, nonblocking AF_PACKET capture socket. Requires CAP_NET_RAW;
 * callers may run without capture and use nftables-only enforcement. */
int antiddos_network_open_capture(const char *interface_name, int promiscuous);

#endif
