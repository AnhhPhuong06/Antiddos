#define _POSIX_C_SOURCE 200809L
#include "connection.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PROBES 64U
struct connection_slot { connection_key_t key; uint64_t hash; uint8_t state; };
struct connection_ip_slot { connection_key_t key; uint64_t hash; size_t count; uint8_t state; };

static bool valid(const connection_key_t *k) {
    return k && (k->address_len == 4 || k->address_len == 16) && k->service_id < 33;
}
static uint64_t hash_key(const connection_key_t *k, bool ip_only) {
    uint64_t h = 1469598103934665603ULL ^ k->service_id;
    if (!ip_only) h ^= ((uint64_t)k->src_port << 16) ^ k->dst_port ^ ((uint64_t)k->protocol << 48);
    for (uint8_t i = 0; i < k->address_len; ++i) { h ^= k->address[i]; h *= 1099511628211ULL; }
    return h;
}
static bool equal(const connection_key_t *a, const connection_key_t *b, bool ip_only) {
    return a->service_id == b->service_id && a->address_len == b->address_len &&
        !memcmp(a->address, b->address, a->address_len) &&
        (ip_only || (a->src_port == b->src_port && a->dst_port == b->dst_port && a->protocol == b->protocol));
}
static struct connection_slot *find(connection_table_t *t, const connection_key_t *k, size_t *free_idx) {
    uint64_t h = hash_key(k, false); *free_idx = SIZE_MAX;
    for (size_t n = 0; n < t->capacity && n < MAX_PROBES; ++n) {
        size_t i = ((size_t)(h % t->capacity) + n) % t->capacity;
        struct connection_slot *s = &t->slots[i];
        if (s->state == 1 && s->hash == h && equal(&s->key, k, false)) return s;
        if (s->state != 1 && *free_idx == SIZE_MAX) *free_idx = i;
        if (!s->state) break;
    }
    return NULL;
}
static struct connection_ip_slot *find_ip(connection_table_t *t, const connection_key_t *k, bool create) {
    uint64_t h = hash_key(k, true); size_t first_free = SIZE_MAX;
    for (size_t n = 0; n < t->capacity && n < MAX_PROBES; ++n) {
        size_t i = ((size_t)(h % t->capacity) + n) % t->capacity;
        struct connection_ip_slot *s = &t->ip_slots[i];
        if (s->state == 1 && s->hash == h && equal(&s->key, k, true)) return s;
        if (s->state != 1 && first_free == SIZE_MAX) first_free = i;
        if (!s->state) break;
    }
    if (!create || first_free == SIZE_MAX) return NULL;
    struct connection_ip_slot *s = &t->ip_slots[first_free];
    memset(s, 0, sizeof(*s)); s->state = 1; s->hash = h; s->key = *k;
    return s;
}
int connection_init(connection_table_t *t, size_t capacity, uint64_t idle) {
    pthread_mutex_t *m;
    if (!t || capacity < 2 || capacity > 1000000) return -1;
    memset(t, 0, sizeof(*t)); t->capacity = capacity * 2 + 1; t->max_entries = capacity;
    t->slots = calloc(t->capacity, sizeof(*t->slots));
    t->ip_slots = calloc(t->capacity, sizeof(*t->ip_slots)); m = calloc(1, sizeof(*m));
    if (!t->slots || !t->ip_slots || !m || pthread_mutex_init(m, NULL)) {
        free(t->slots); free(t->ip_slots); free(m); memset(t, 0, sizeof(*t)); return -1;
    }
    t->idle_timeout_ns = idle; t->lock = m; return 0;
}
void connection_destroy(connection_table_t *t) {
    if (!t) return;
    if (t->lock) { pthread_mutex_destroy(t->lock); free(t->lock); }
    free(t->slots); free(t->ip_slots); memset(t, 0, sizeof(*t));
}
int connection_open(connection_table_t *t, const connection_key_t *k, uint64_t now) {
    size_t free_idx; int result;
    if (!t || !t->lock || !valid(k)) return -1;
    pthread_mutex_lock(t->lock);
    struct connection_slot *s = find(t, k, &free_idx);
    if (s) { s->key.last_seen_ns = now; result = 1; }
    else if (free_idx == SIZE_MAX || t->size >= t->max_entries) result = -2;
    else {
        struct connection_ip_slot *ip = find_ip(t, k, true);
        if (!ip) result = -2;
        else {
            s = &t->slots[free_idx]; memset(s, 0, sizeof(*s));
            s->state = 1; s->hash = hash_key(k, false); s->key = *k;
            s->key.accepted_ns = s->key.last_seen_ns = now;
            ++ip->count; ++t->service_counts[k->service_id]; ++t->size; result = 0;
        }
    }
    pthread_mutex_unlock(t->lock); return result;
}
int connection_touch(connection_table_t *t, const connection_key_t *k, uint64_t now) {
    size_t free_idx;
    if (!t || !t->lock || !valid(k)) return -1;
    pthread_mutex_lock(t->lock);
    struct connection_slot *s = find(t, k, &free_idx);
    if (s) s->key.last_seen_ns = now;
    pthread_mutex_unlock(t->lock); return s ? 0 : -1;
}
static void erase(connection_table_t *t, struct connection_slot *s) {
    struct connection_ip_slot *ip = find_ip(t, &s->key, false);
    if (ip && ip->count && --ip->count == 0) ip->state = 2;
    --t->service_counts[s->key.service_id]; --t->size;
    memset(s, 0, sizeof(*s)); s->state = 2;
}
int connection_close(connection_table_t *t, const connection_key_t *k) {
    size_t free_idx;
    if (!t || !t->lock || !valid(k)) return -1;
    pthread_mutex_lock(t->lock);
    struct connection_slot *s = find(t, k, &free_idx);
    if (s) erase(t, s);
    pthread_mutex_unlock(t->lock); return s ? 0 : -1;
}
size_t connection_cleanup(connection_table_t *t, uint64_t now, size_t budget) {
    size_t removed = 0;
    if (!t || !t->lock || !t->idle_timeout_ns) return 0;
    if (budget > t->capacity) budget = t->capacity;
    pthread_mutex_lock(t->lock);
    for (size_t n = 0; n < budget; ++n) {
        struct connection_slot *s = &t->slots[t->cleanup_cursor];
        t->cleanup_cursor = (t->cleanup_cursor + 1) % t->capacity;
        if (s->state == 1 && now >= s->key.last_seen_ns && now - s->key.last_seen_ns >= t->idle_timeout_ns) {
            erase(t, s); ++removed;
        }
    }
    pthread_mutex_unlock(t->lock); return removed;
}
size_t connection_count(const connection_table_t *t) {
    if (!t || !t->lock) return 0;
    pthread_mutex_lock(t->lock); size_t n = t->size; pthread_mutex_unlock(t->lock); return n;
}
size_t connection_count_service(const connection_table_t *t, uint32_t id) {
    if (!t || !t->lock || id >= 33) return 0;
    pthread_mutex_lock(t->lock); size_t n = t->service_counts[id]; pthread_mutex_unlock(t->lock); return n;
}
size_t connection_count_ip(const connection_table_t *t, const uint8_t *address, uint8_t len, uint32_t id) {
    connection_key_t k = {0};
    if (!t || !t->lock || !address || (len != 4 && len != 16) || id >= 33) return 0;
    k.address_len = len; k.service_id = id; memcpy(k.address, address, len);
    pthread_mutex_lock(t->lock);
    struct connection_ip_slot *s = find_ip((connection_table_t *)t, &k, false);
    size_t count = s ? s->count : 0;
    pthread_mutex_unlock(t->lock); return count;
}
