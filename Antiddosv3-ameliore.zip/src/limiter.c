#include "limiter.h"

#include <pthread.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct limiter_bucket {
    uint64_t hash;
    limiter_key_t key;
    double tokens;
    uint64_t last_ns;
    uint8_t state; /* 0 empty, 1 occupied, 2 tombstone */
};

static uint64_t hash_key(const limiter_key_t *k) {
    const uint8_t *p = (const uint8_t *)k;
    uint64_t h = 1469598103934665603ULL;
    /* Hash only deterministic bytes and avoid padding. */
    h ^= (uint8_t)k->type; h *= 1099511628211ULL;
    h ^= k->len; h *= 1099511628211ULL;
    h ^= k->prefix_len; h *= 1099511628211ULL;
    for (uint8_t i = 0; i < k->len && i < sizeof(k->bytes); ++i) { h ^= k->bytes[i]; h *= 1099511628211ULL; }
    h ^= (uint8_t)(k->port >> 8); h *= 1099511628211ULL;
    h ^= (uint8_t)k->port; h *= 1099511628211ULL;
    for (unsigned i = 0; i < 4; ++i) { h ^= p[offsetof(limiter_key_t, service) + i]; h *= 1099511628211ULL; }
    h ^= k->protocol; h *= 1099511628211ULL;
    return h;
}
static bool key_equal(const limiter_key_t *a, const limiter_key_t *b) {
    return a->type == b->type && a->len == b->len && a->prefix_len == b->prefix_len && a->port == b->port &&
           a->service == b->service && a->protocol == b->protocol &&
           (a->len == 0 || memcmp(a->bytes, b->bytes, a->len) == 0);
}
int limiter_init(limiter_t *l, const limiter_config_t *c) {
    if (!l || !c || c->capacity < 2 || c->capacity > 1000000 ||
        !isfinite(c->rate) || !isfinite(c->burst) || c->rate <= 0.0 || c->burst <= 0.0) return -1;
    memset(l, 0, sizeof(*l));
    l->buckets = calloc(c->capacity, sizeof(*l->buckets));
    if (!l->buckets) { memset(l, 0, sizeof(*l)); return -1; }
    if (pthread_mutex_init(&l->lock, NULL) != 0) { free(l->buckets); memset(l, 0, sizeof(*l)); return -1; }
    l->capacity = c->capacity; l->rate = c->rate; l->burst = c->burst;
    l->idle_timeout_ns = c->idle_timeout_ns; l->lock_initialized = true;
    return 0;
}
void limiter_destroy(limiter_t *l) {
    if (!l) return;
    if (l->lock_initialized) pthread_mutex_destroy(&l->lock);
    free(l->buckets); memset(l, 0, sizeof(*l));
}
void limiter_key_global(limiter_key_t *k) { if (k) memset(k, 0, sizeof(*k)); }
void limiter_key_ip(limiter_key_t *k, const uint8_t *a, uint8_t n) {
    if (!k) return; memset(k, 0, sizeof(*k)); k->type = LIMIT_KEY_IP;
    if (a && (n == 4 || n == 16)) { memcpy(k->bytes, a, n); k->len = n; }
}
void limiter_key_subnet(limiter_key_t *k, const uint8_t *a, uint8_t n, uint8_t prefix_len) {
    if (!k) return; memset(k, 0, sizeof(*k)); k->type = LIMIT_KEY_SUBNET;
    if (!a || (n != 4 && n != 16) || prefix_len > (uint8_t)(n * 8U)) return;
    memcpy(k->bytes, a, n); k->len = n; k->prefix_len = prefix_len;
    for (uint8_t bit = prefix_len; bit < (uint8_t)(n * 8U); ++bit)
        k->bytes[bit / 8U] &= (uint8_t)~(1U << (7U - (bit % 8U)));
}
void limiter_key_port(limiter_key_t *k, uint16_t p) { if (k) { memset(k, 0, sizeof(*k)); k->type = LIMIT_KEY_PORT; k->port = p; } }
void limiter_key_service(limiter_key_t *k, uint32_t s) { if (k) { memset(k, 0, sizeof(*k)); k->type = LIMIT_KEY_SERVICE; k->service = s; } }
void limiter_key_protocol(limiter_key_t *k, uint8_t p) { if (k) { memset(k, 0, sizeof(*k)); k->type = LIMIT_KEY_PROTOCOL; k->protocol = p; } }

bool limiter_allow(limiter_t *l, const limiter_key_t *k, double amount, uint64_t now_ns) {
    uint64_t h; size_t idx, first_free = SIZE_MAX; struct limiter_bucket *b = NULL;
    bool allowed = false;
    if (!l || !l->buckets || !l->lock_initialized || !k || k->len > sizeof(k->bytes) ||
        !isfinite(amount) || amount < 0.0 || amount > l->burst * 4.0) return false;
    h = hash_key(k); pthread_mutex_lock(&l->lock); idx = (size_t)(h % l->capacity);
    for (size_t n = 0; n < l->capacity && n < 64; ++n) {
        struct limiter_bucket *cur = &l->buckets[(idx + n) % l->capacity];
        if (cur->state != 1 && first_free == SIZE_MAX) first_free = (idx + n) % l->capacity;
        if (!cur->state) break;
        if (cur->state == 1 && cur->hash == h && key_equal(&cur->key, k)) { b = cur; break; }
    }
    if (!b) {
        if (first_free == SIZE_MAX) { pthread_mutex_unlock(&l->lock); return false; }
        b = &l->buckets[first_free]; b->state = 1; b->hash = h; b->key = *k; ++l->size;
        b->tokens = l->burst; b->last_ns = now_ns;
    }
    if (now_ns >= b->last_ns) {
        uint64_t delta = now_ns - b->last_ns;
        double add = ((double)delta / 1000000000.0) * l->rate;
        b->tokens = (add >= l->burst || b->tokens > l->burst - add) ? l->burst : b->tokens + add;
        b->last_ns = now_ns;
    } else {
        b->last_ns = now_ns; /* clock correction: do not mint tokens */
    }
    if (b->tokens >= amount) { b->tokens -= amount; allowed = true; }
    pthread_mutex_unlock(&l->lock); return allowed;
}
size_t limiter_cleanup(limiter_t *l, uint64_t now_ns) {
    size_t removed = 0;
    if (!l || !l->lock_initialized || l->idle_timeout_ns == 0) return 0;
    pthread_mutex_lock(&l->lock);
    size_t budget = l->capacity < 1024 ? l->capacity : 1024;
    for (size_t n = 0; n < budget; ++n) {
        size_t i = l->cleanup_cursor; l->cleanup_cursor = (i + 1) % l->capacity;
        struct limiter_bucket *b = &l->buckets[i];
        if (b->state == 1 && now_ns >= b->last_ns && now_ns - b->last_ns >= l->idle_timeout_ns) {
            memset(b, 0, sizeof(*b)); b->state = 2; ++removed; --l->size;
        }
    }
    pthread_mutex_unlock(&l->lock); return removed;
}
size_t limiter_size(const limiter_t *l) {
    size_t n = 0; if (!l || !l->lock_initialized) return 0;
    pthread_mutex_lock((pthread_mutex_t *)&l->lock); n = l->size; pthread_mutex_unlock((pthread_mutex_t *)&l->lock); return n;
}
