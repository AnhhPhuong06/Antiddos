#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#define _POSIX_C_SOURCE 200809L
#include "firewall.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <signal.h>
#include <spawn.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static int canonical(const char *input, char *output) {
    struct in_addr a4; struct in6_addr a6;
    if (!input) return -1;
    if (inet_pton(AF_INET, input, &a4) == 1) return inet_ntop(AF_INET, &a4, output, INET6_ADDRSTRLEN) ? 0 : -1;
    if (inet_pton(AF_INET6, input, &a6) == 1) return inet_ntop(AF_INET6, &a6, output, INET6_ADDRSTRLEN) ? 0 : -1;
    return -1;
}
static uint64_t monotonic_ms(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}
/* One bounded subprocess per transaction, outside packet processing. */
static int run_batch(FILE *input) {
    const char *binary = access("/usr/sbin/nft", X_OK) == 0 ? "/usr/sbin/nft" : "/sbin/nft";
    char *argv[] = {(char *)binary, "-f", "-", NULL};
    char *environment[] = {"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL=C", NULL};
    posix_spawn_file_actions_t actions; pid_t pid; int status;
    if (fflush(input) || fseek(input, 0, SEEK_SET)) return -1;
    if (posix_spawn_file_actions_init(&actions)) return -1;
    int err = posix_spawn_file_actions_adddup2(&actions, fileno(input), STDIN_FILENO);
    if (!err) err = posix_spawn(&pid, binary, &actions, NULL, argv, environment);
    posix_spawn_file_actions_destroy(&actions);
    if (err) return -1;
    uint64_t deadline = monotonic_ms() + 3000;
    struct timespec pause = {0, 10000000};
    for (;;) {
        pid_t result = waitpid(pid, &status, WNOHANG);
        if (result == pid) return WIFEXITED(status) && WEXITSTATUS(status) == 0 ? 0 : -1;
        if (result < 0 && errno != EINTR) return -1;
        if (monotonic_ms() >= deadline) {
            (void)kill(pid, SIGKILL);
            while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
            return -1;
        }
        nanosleep(&pause, NULL);
    }
}
static uint64_t byte_burst(uint64_t bps) { return bps / 8 < 65536 ? 65536 : bps / 8; }
static void rate(FILE *out, uint64_t pps, uint64_t bps, uint32_t burst) {
    fprintf(out, "  limit rate over %" PRIu64 "/second burst %u packets counter name rate_dropped drop\n", pps, burst);
    fprintf(out, "  limit rate over %" PRIu64 " bytes/second burst %" PRIu64 " bytes counter name rate_dropped drop\n", bps / 8, byte_burst(bps));
}
static void dynamic_set(FILE *out, const char *name, uint32_t id, int v6, uint32_t size, int timeout) {
    fprintf(out, " set %s%u_%u { type %s; flags dynamic%s; size %u;%s }\n", name, id, v6 ? 6U : 4U,
            v6 ? "ipv6_addr" : "ipv4_addr", timeout ? ",timeout" : "", size, timeout ? " timeout 60s;" : "");
}
int antiddos_firewall_write_policy(FILE *out, const antiddos_config_t *cfg) {
    if (!out || antiddos_config_validate(cfg) || !cfg->service_count) return -1;
    /* Replaces this tool's table atomically; other firewall tables are untouched. */
    fputs("add table inet antiddos\ndelete table inet antiddos\ntable inet antiddos {\n", out);
    fputs(" counter protected_input {}\n counter passed {}\n counter rate_dropped {}\n counter banned_dropped {}\n counter invalid_dropped {}\n", out);
    fputs(" set blocked { type ipv4_addr; flags timeout; size 4096; }\n set blocked6 { type ipv6_addr; flags timeout; size 4096; }\n", out);
    fputs(" set trusted { type ipv4_addr; size 4096; }\n set trusted6 { type ipv6_addr; size 4096; }\n", out);
    fputs(" set total_tcp { type inet_proto; flags dynamic; size 1; }\n", out);
    for (size_t i = 0; i < cfg->service_count; ++i) {
        uint32_t id = (uint32_t)i + 1;
        for (int v6 = 0; v6 < 2; ++v6) {
            fprintf(out, " set ban%u_%u { type %s; flags timeout; size 4096; }\n", id, v6 ? 6U : 4U, v6 ? "ipv6_addr" : "ipv4_addr");
            dynamic_set(out, "pps", id, v6, cfg->max_ip_entries, 1);
            dynamic_set(out, "bytes", id, v6, cfg->max_ip_entries, 1);
            if (cfg->services[i].protocol == ANTIDDOS_PROTO_TCP) {
                dynamic_set(out, "syn", id, v6, cfg->max_ip_entries, 1);
                dynamic_set(out, "conn", id, v6, cfg->max_ip_entries, 0);
            }
        }
        if (cfg->services[i].protocol == ANTIDDOS_PROTO_TCP)
            fprintf(out, " set total%u { type inet_service; flags dynamic; size 1; }\n", id);
    }
    fputs(" chain global_limits {\n  ct state invalid counter name invalid_dropped drop\n", out);
    fprintf(out, "  meta l4proto tcp ct state new add @total_tcp { meta l4proto ct count over %u } counter name rate_dropped drop\n", cfg->max_connections);
    rate(out, cfg->pps_limit, cfg->bps_limit, cfg->rate_burst_packets);
    fprintf(out, "  tcp flags & (fin | syn | rst | ack) == syn limit rate over %" PRIu64 "/second burst %u packets counter name rate_dropped drop\n", cfg->syn_limit, cfg->rate_burst_packets);
    fprintf(out, "  meta l4proto udp limit rate over %" PRIu64 "/second burst %u packets counter name rate_dropped drop\n", cfg->udp_limit, cfg->rate_burst_packets);
    fprintf(out, "  meta l4proto { icmp, ipv6-icmp } limit rate over %" PRIu64 "/second burst %u packets counter name rate_dropped drop\n }\n", cfg->icmp_limit, cfg->rate_burst_packets);
    for (size_t i = 0; i < cfg->service_count; ++i) {
        const antiddos_service_config_t *s = &cfg->services[i]; uint32_t id = (uint32_t)i + 1;
        fprintf(out, " chain service%u {\n  ip saddr @ban%u_4 counter name banned_dropped drop\n  ip6 saddr @ban%u_6 counter name banned_dropped drop\n  jump global_limits\n", id, id, id);
        rate(out, s->pps_limit, s->bps_limit, cfg->rate_burst_packets);
        for (int v6 = 0; v6 < 2; ++v6) {
            const char *family = v6 ? "ip6" : "ip"; unsigned version = v6 ? 6U : 4U;
            fprintf(out, "  update @pps%u_%u { %s saddr limit rate over %" PRIu64 "/second burst %u packets } counter name rate_dropped drop\n", id, version, family, cfg->ip_pps_limit, cfg->rate_burst_packets);
            fprintf(out, "  update @bytes%u_%u { %s saddr limit rate over %" PRIu64 " bytes/second burst %" PRIu64 " bytes } counter name rate_dropped drop\n", id, version, family, cfg->ip_bps_limit / 8, byte_burst(cfg->ip_bps_limit));
            if (s->protocol == ANTIDDOS_PROTO_TCP) {
                fprintf(out, "  tcp flags & (fin | syn | rst | ack) == syn update @syn%u_%u { %s saddr limit rate over %u/second burst %u packets } counter name rate_dropped drop\n", id, version, family, cfg->ip_syn_limit, cfg->rate_burst_packets);
                fprintf(out, "  ct state new add @conn%u_%u { %s saddr ct count over %u } counter name rate_dropped drop\n", id, version, family, cfg->max_connections_per_ip);
            }
        }
        if (s->protocol == ANTIDDOS_PROTO_TCP)
            fprintf(out, "  ct state new add @total%u { tcp dport ct count over %u } counter name rate_dropped drop\n", id, s->connection_limit);
        fputs("  counter name passed\n }\n", out);
    }
    fputs(" chain input_guard {\n  type filter hook input priority -100; policy accept;\n  ip saddr @trusted accept\n  ip6 saddr @trusted6 accept\n  ip saddr @blocked counter name banned_dropped drop\n  ip6 saddr @blocked6 counter name banned_dropped drop\n", out);
    for (size_t i = 0; i < cfg->service_count; ++i) {
        const antiddos_service_config_t *s = &cfg->services[i];
        fputs("  ", out);
        if (cfg->capture_interface[0]) fprintf(out, "iifname \"%s\" ", cfg->capture_interface);
        if (strcmp(s->listen_ip, "0.0.0.0") && strcmp(s->listen_ip, "::")) {
            char address[INET6_ADDRSTRLEN]; if (canonical(s->listen_ip, address)) return -1;
            fprintf(out, "%s daddr %s ", strchr(address, ':') ? "ip6" : "ip", address);
        }
        if (s->protocol == ANTIDDOS_PROTO_ICMP) fputs("meta l4proto { icmp, ipv6-icmp } ", out);
        else fprintf(out, "%s dport %u ", s->protocol == ANTIDDOS_PROTO_TCP ? "tcp" : "udp", s->listen_port);
        fprintf(out, "counter name protected_input jump service%zu\n", i + 1);
    }
    fputs(" }\n}\n", out); return ferror(out) ? -1 : 0;
}
static void changed(antiddos_firewall_t *fw) { fw->dirty = 1; ++fw->generation; pthread_cond_signal(&fw->changed); }
int antiddos_firewall_init(antiddos_firewall_t *fw, int enabled, const char *table, const char *set_name) {
    if (!fw) return -1; memset(fw, 0, sizeof(*fw));
    snprintf(fw->table, sizeof(fw->table), "%s", table && *table ? table : "antiddos");
    snprintf(fw->set_name, sizeof(fw->set_name), "%s", set_name && *set_name ? set_name : "blocked");
    snprintf(fw->set_name_v6, sizeof(fw->set_name_v6), "%.30s6", fw->set_name);
    if (pthread_mutex_init(&fw->lock, NULL)) return -1;
    if (pthread_cond_init(&fw->changed, NULL)) { pthread_mutex_destroy(&fw->lock); return -1; }
    fw->enabled = enabled != 0; fw->lock_ready = 1; return 0;
}
static int add_rule(antiddos_firewall_t *fw, const char *address, uint32_t service, uint32_t ttl, int permanent, int trusted) {
    char ip[INET6_ADDRSTRLEN];
    if (!fw || !fw->lock_ready || service > ANTIDDOS_MAX_SERVICES || canonical(address, ip)) return -1;
    uint64_t expires = permanent ? 0 : (uint64_t)time(NULL) + (ttl ? ttl : 60);
    pthread_mutex_lock(&fw->lock);
    for (size_t i = 0; i < fw->count; ++i) {
        antiddos_firewall_rule_t *r = &fw->rules[i];
        if (r->service_id == service && !strcmp(r->address, ip) && r->trusted == trusted) {
            if (r->permanent != permanent || r->expires_at != expires) {
                r->permanent = permanent; r->expires_at = expires; changed(fw);
            }
            pthread_mutex_unlock(&fw->lock); return 0;
        }
    }
    if (fw->count == ANTIDDOS_FIREWALL_MAX_RULES) { pthread_mutex_unlock(&fw->lock); return -2; }
    antiddos_firewall_rule_t *r = &fw->rules[fw->count++]; memset(r, 0, sizeof(*r));
    memcpy(r->address, ip, strlen(ip) + 1); r->service_id = service; r->permanent = permanent;
    r->expires_at = expires; r->trusted = trusted; changed(fw);
    pthread_mutex_unlock(&fw->lock); return 0;
}
int antiddos_firewall_add(antiddos_firewall_t *fw, const char *address, uint32_t ttl, int permanent) {
    return add_rule(fw, address, 0, ttl, permanent != 0, 0);
}
int antiddos_firewall_add_service(antiddos_firewall_t *fw, const char *address, uint32_t service, uint32_t ttl) {
    return service ? add_rule(fw, address, service, ttl, 0, 0) : -1;
}
int antiddos_firewall_set_trusted(antiddos_firewall_t *fw, const char *address, int trusted) {
    char ip[INET6_ADDRSTRLEN]; if (!fw || !fw->lock_ready || canonical(address, ip)) return -1;
    pthread_mutex_lock(&fw->lock);
    for (size_t i = 0; i < fw->count;) {
        if (!strcmp(fw->rules[i].address, ip) && (trusted || fw->rules[i].trusted)) {
            fw->rules[i] = fw->rules[--fw->count]; changed(fw);
        } else ++i;
    }
    pthread_mutex_unlock(&fw->lock);
    return trusted ? add_rule(fw, ip, 0, 0, 1, 1) : 0;
}
int antiddos_firewall_remove(antiddos_firewall_t *fw, const char *address) {
    char ip[INET6_ADDRSTRLEN]; if (!fw || !fw->lock_ready || canonical(address, ip)) return -1;
    int result = -1; pthread_mutex_lock(&fw->lock);
    for (size_t i = 0; i < fw->count;) {
        if (!fw->rules[i].service_id && !fw->rules[i].trusted && !strcmp(fw->rules[i].address, ip)) {
            fw->rules[i] = fw->rules[--fw->count]; changed(fw); result = 0;
        } else ++i;
    }
    pthread_mutex_unlock(&fw->lock); return result;
}
size_t antiddos_firewall_expire(antiddos_firewall_t *fw, uint64_t now) {
    if (!fw || !fw->lock_ready) return 0;
    size_t removed = 0; pthread_mutex_lock(&fw->lock);
    for (size_t i = 0; i < fw->count;) {
        if (!fw->rules[i].permanent && fw->rules[i].expires_at <= now) {
            fw->rules[i] = fw->rules[--fw->count]; ++removed; changed(fw);
        } else ++i;
    }
    pthread_mutex_unlock(&fw->lock); return removed;
}
int antiddos_firewall_flush(antiddos_firewall_t *fw) {
    if (!fw || !fw->lock_ready) return -1;
    pthread_mutex_lock(&fw->lock);
    for (size_t i = 0; i < fw->count;) {
        if (!fw->rules[i].permanent) fw->rules[i] = fw->rules[--fw->count]; else ++i;
    }
    changed(fw); pthread_mutex_unlock(&fw->lock); return 0;
}
int antiddos_firewall_sync(antiddos_firewall_t *fw) {
    if (!fw || !fw->lock_ready) return -1;
    pthread_mutex_lock(&fw->lock);
    if (!fw->enabled || !fw->dirty) { pthread_mutex_unlock(&fw->lock); return 0; }
    FILE *batch = tmpfile();
    if (!batch) { fw->healthy = 0; pthread_mutex_unlock(&fw->lock); return -1; }
    uint64_t generation = fw->generation, now = (uint64_t)time(NULL);
    fputs("flush set inet antiddos blocked\nflush set inet antiddos blocked6\nflush set inet antiddos trusted\nflush set inet antiddos trusted6\n", batch);
    for (size_t i = 0; i < fw->config.service_count; ++i)
        fprintf(batch, "flush set inet antiddos ban%zu_4\nflush set inet antiddos ban%zu_6\n", i + 1, i + 1);
    for (size_t i = 0; i < fw->count; ++i) {
        const antiddos_firewall_rule_t *r = &fw->rules[i];
        if (!r->permanent && r->expires_at <= now) continue;
        char set[32]; int v6 = strchr(r->address, ':') != NULL;
        if (r->service_id) snprintf(set, sizeof(set), "ban%u_%u", r->service_id, v6 ? 6U : 4U);
        else snprintf(set, sizeof(set), "%s%s", r->trusted ? "trusted" : "blocked", v6 ? "6" : "");
        fprintf(batch, "add element inet antiddos %s { %s", set, r->address);
        if (!r->permanent) fprintf(batch, " timeout %" PRIu64 "s", r->expires_at - now);
        fputs(" }\n", batch);
    }
    pthread_mutex_unlock(&fw->lock);
    int result = ferror(batch) ? -1 : run_batch(batch); fclose(batch);
    pthread_mutex_lock(&fw->lock); fw->healthy = result == 0;
    if (!result && fw->generation == generation) fw->dirty = 0;
    pthread_mutex_unlock(&fw->lock); return result;
}
static void *worker_main(void *argument) {
    antiddos_firewall_t *fw = argument;
    for (;;) {
        pthread_mutex_lock(&fw->lock);
        while (!fw->dirty && !fw->stopping) pthread_cond_wait(&fw->changed, &fw->lock);
        int stop = fw->stopping; pthread_mutex_unlock(&fw->lock);
        if (stop) break;
        if (antiddos_firewall_sync(fw)) {
            struct timespec deadline; clock_gettime(CLOCK_REALTIME, &deadline); ++deadline.tv_sec;
            pthread_mutex_lock(&fw->lock);
            if (!fw->stopping) (void)pthread_cond_timedwait(&fw->changed, &fw->lock, &deadline);
            pthread_mutex_unlock(&fw->lock);
        }
    }
    return NULL;
}
int antiddos_firewall_start(antiddos_firewall_t *fw, const antiddos_config_t *cfg) {
    if (!fw || !fw->lock_ready || !cfg || fw->worker_ready || strcmp(fw->table, "antiddos") || strcmp(fw->set_name, "blocked")) return -1;
    fw->config = *cfg;
    if (!fw->enabled) return 0;
    FILE *policy = tmpfile(); if (!policy) return -1;
    int result = antiddos_firewall_write_policy(policy, cfg);
    if (!result) result = run_batch(policy);
    fclose(policy); if (result) return -1;
    fw->healthy = 1;
    if (pthread_create(&fw->worker, NULL, worker_main, fw)) { fw->healthy = 0; return -1; }
    fw->worker_ready = 1; return 0;
}
void antiddos_firewall_close(antiddos_firewall_t *fw) {
    if (!fw || !fw->lock_ready) return;
    if (fw->worker_ready) {
        pthread_mutex_lock(&fw->lock); fw->stopping = 1; pthread_cond_signal(&fw->changed); pthread_mutex_unlock(&fw->lock);
        pthread_join(fw->worker, NULL);
    }
    pthread_cond_destroy(&fw->changed); pthread_mutex_destroy(&fw->lock); fw->lock_ready = 0;
}
size_t antiddos_firewall_count(const antiddos_firewall_t *fw) {
    if (!fw || !fw->lock_ready) return 0;
    size_t count = 0; uint64_t now = (uint64_t)time(NULL);
    pthread_mutex_lock((pthread_mutex_t *)&fw->lock);
    for (size_t i = 0; i < fw->count; ++i)
        count += !fw->rules[i].trusted && (fw->rules[i].permanent || fw->rules[i].expires_at > now);
    pthread_mutex_unlock((pthread_mutex_t *)&fw->lock); return count;
}
