#define _POSIX_C_SOURCE 200809L
#include "logger.h"
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

static const char *level_name(antiddos_log_level_t level) {
    switch (level) {
    case ANTIDDOS_LOG_DEBUG: return "DEBUG";
    case ANTIDDOS_LOG_INFO: return "INFO";
    case ANTIDDOS_LOG_WARNING: return "WARNING";
    case ANTIDDOS_LOG_SECURITY: return "SECURITY";
    case ANTIDDOS_LOG_ERROR: return "ERROR";
    default: return "UNKNOWN";
    }
}

int antiddos_logger_init(antiddos_logger_t *logger, const char *path,
                         antiddos_log_level_t min_level, uint32_t max_lines_per_sec) {
    if (!logger) return -1;
    if (path && strlen(path) >= 256U) return -1;
    memset(logger, 0, sizeof(*logger));
    logger->fp = stderr;
    if (path && *path && strcmp(path, "stderr") != 0) {
        logger->fp = fopen(path, "a");
        if (!logger->fp) return -1;
        (void)snprintf(logger->path, sizeof(logger->path), "%s", path);
    }
    logger->max_bytes = 10U * 1024U * 1024U;
    logger->min_level = min_level;
    logger->max_lines_per_sec = max_lines_per_sec ? max_lines_per_sec : 100;
    logger->window = time(NULL);
    if (pthread_mutex_init(&logger->lock, NULL) != 0) {
        if (logger->fp != stderr) fclose(logger->fp);
        logger->fp = NULL;
        return -1;
    }
    logger->lock_ready = 1;
    return 0;
}

void antiddos_logger_close(antiddos_logger_t *logger) {
    if (!logger) return;
    if (logger->lock_ready) pthread_mutex_lock(&logger->lock);
    if (logger->fp && logger->fp != stderr) fclose(logger->fp);
    logger->fp = NULL;
    if (logger->lock_ready) {
        pthread_mutex_unlock(&logger->lock);
        pthread_mutex_destroy(&logger->lock);
    }
    logger->lock_ready = 0;
}

void antiddos_logger_vwrite(antiddos_logger_t *logger, antiddos_log_level_t level,
                            const char *event, const char *fmt, va_list ap) {
    time_t now;
    struct tm tm_now;
    char ts[32];
    if (!logger || !logger->fp || level < logger->min_level || !fmt) return;
    pthread_mutex_lock(&logger->lock);
    now = time(NULL);
    if (now != logger->window) { logger->window = now; logger->lines = 0; }
    if (logger->lines >= logger->max_lines_per_sec) { pthread_mutex_unlock(&logger->lock); return; }
    logger->lines++;
    if (logger->fp != stderr && logger->path[0]) {
        long position = ftell(logger->fp);
        if (position >= 0 && (unsigned long)position >= logger->max_bytes) {
            char rotated[sizeof(logger->path) + 8U];
            (void)snprintf(rotated, sizeof(rotated), "%s.1", logger->path);
            fclose(logger->fp);
            (void)rename(logger->path, rotated);
            logger->fp = fopen(logger->path, "a");
            if (!logger->fp) { logger->fp = stderr; logger->path[0] = '\0'; }
        }
    }
    if (!localtime_r(&now, &tm_now)) { pthread_mutex_unlock(&logger->lock); return; }
    (void)strftime(ts, sizeof(ts), "%Y-%m-%dT%H:%M:%S%z", &tm_now);
    fprintf(logger->fp, "%s level=%s event=%s ", ts, level_name(level), event ? event : "-");
    vfprintf(logger->fp, fmt, ap);
    fputc('\n', logger->fp);
    fflush(logger->fp);
    pthread_mutex_unlock(&logger->lock);
}

void antiddos_logger_write(antiddos_logger_t *logger, antiddos_log_level_t level,
                           const char *event, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    antiddos_logger_vwrite(logger, level, event, fmt, ap);
    va_end(ap);
}
