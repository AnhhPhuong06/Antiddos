#define _POSIX_C_SOURCE 200809L
#include "config.h"
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <arpa/inet.h>

static char *trim(char *s) {
    char *end;
    while (*s && isspace((unsigned char)*s)) ++s;
    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) --end;
    *end = '\0';
    return s;
}

static int parse_u64(const char *s, uint64_t *out) {
    char *end = NULL;
    const char *tail;
    unsigned long long v;
    if (!s || !*s || *s == '-') return -1;
    errno = 0;
    v = strtoull(s, &end, 10);
    tail = end;
    while (*tail && isspace((unsigned char)*tail)) ++tail;
    if (errno == ERANGE || end == s || *tail != '\0') return -1;
    *out = (uint64_t)v;
    return 0;
}

static int parse_u32(const char *s, uint32_t *out) {
    uint64_t v;
    if (parse_u64(s, &v) != 0 || v > UINT32_MAX) return -1;
    *out = (uint32_t)v;
    return 0;
}

static int parse_bool(const char *s, int *out) {
    if (!strcasecmp(s, "1") || !strcasecmp(s, "true") || !strcasecmp(s, "yes") || !strcasecmp(s, "on")) {
        *out = 1; return 0;
    }
    if (!strcasecmp(s, "0") || !strcasecmp(s, "false") || !strcasecmp(s, "no") || !strcasecmp(s, "off")) {
        *out = 0; return 0;
    }
    return -1;
}

static int copy_string(char *dst, size_t dst_len, const char *src) {
    int n;
    if (!dst || !src || dst_len == 0) return -1;
    n = snprintf(dst, dst_len, "%s", src);
    return (n < 0 || (size_t)n >= dst_len) ? -1 : 0;
}

static antiddos_protocol_t parse_proto(const char *s) {
    if (!strcasecmp(s, "tcp") || !strcmp(s, "6")) return ANTIDDOS_PROTO_TCP;
    if (!strcasecmp(s, "udp") || !strcmp(s, "17")) return ANTIDDOS_PROTO_UDP;
    if (!strcasecmp(s, "icmp") || !strcmp(s, "1")) return ANTIDDOS_PROTO_ICMP;
    return 0;
}

void antiddos_config_defaults(antiddos_config_t *cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    (void)snprintf(cfg->listen_ip, sizeof(cfg->listen_ip), "%s", "0.0.0.0");
    cfg->capture_interface[0] = '\0';
    cfg->listen_port = 0;
    cfg->pps_limit = 100000;
    cfg->bps_limit = 1000000000ULL;
    cfg->syn_limit = 10000;
    cfg->udp_limit = 100000;
    cfg->icmp_limit = 10000;
    cfg->max_connections = 100000;
    cfg->max_connections_per_ip = 256;
    cfg->ip_pps_limit = 5000;
    cfg->ip_bps_limit = 50000000;
    cfg->ip_syn_limit = 100;
    cfg->rate_burst_packets = 256;
    cfg->capture_batch_packets = 256;
    cfg->suspicious_threshold = 50;
    cfg->attack_threshold = 100;
    cfg->temporary_ban_seconds = 60;
    cfg->max_ip_entries = 100000;
    cfg->worker_threads = 1;
    cfg->max_log_lines_per_second = 100;
    cfg->management_poll_ms = 100;
    cfg->enable_firewall = 0;
    (void)snprintf(cfg->management_socket, sizeof(cfg->management_socket), "%s", "/run/antiddos.sock");
}

int antiddos_config_validate(const antiddos_config_t *cfg) {
    size_t i;
    struct in_addr a4; struct in6_addr a6;
    if (!cfg || !cfg->listen_ip[0] || cfg->worker_threads != 1 ||
        cfg->max_ip_entries < 2 || cfg->max_ip_entries > 1000000U ||
        cfg->max_connections < 2 || cfg->max_connections > 1000000U ||
        cfg->pps_limit == 0 || cfg->bps_limit == 0 || cfg->syn_limit == 0 || cfg->udp_limit == 0 || cfg->icmp_limit == 0 ||
        cfg->max_connections_per_ip == 0 || cfg->max_connections_per_ip > cfg->max_connections ||
        cfg->ip_pps_limit == 0 || cfg->ip_bps_limit < 8 || cfg->ip_syn_limit == 0 ||
        cfg->rate_burst_packets == 0 || cfg->rate_burst_packets > 1000000 ||
        cfg->capture_batch_packets == 0 || cfg->capture_batch_packets > 4096 ||
        cfg->bps_limit < 8 || cfg->temporary_ban_seconds == 0 || cfg->temporary_ban_seconds > 3600 ||
        cfg->suspicious_threshold == 0 || cfg->suspicious_threshold >= cfg->attack_threshold ||
        cfg->attack_threshold - cfg->suspicious_threshold < 2 ||
        cfg->service_count > ANTIDDOS_MAX_SERVICES || cfg->management_socket[0] == '\0') return -1;
    if (inet_pton(AF_INET, cfg->listen_ip, &a4) != 1 && inet_pton(AF_INET6, cfg->listen_ip, &a6) != 1) return -1;
    for (const char *p = cfg->capture_interface; *p; ++p)
        if (!isalnum((unsigned char)*p) && !strchr("_.:-", *p)) return -1;
    for (i = 0; i < cfg->service_count; ++i) {
        const antiddos_service_config_t *s = &cfg->services[i];
        if (!s->service_id[0] || !s->listen_ip[0] || ((!s->listen_port) && s->protocol != ANTIDDOS_PROTO_ICMP) || !s->pps_limit || s->bps_limit < 8 || !s->connection_limit ||
            (s->protocol != ANTIDDOS_PROTO_TCP && s->protocol != ANTIDDOS_PROTO_UDP && s->protocol != ANTIDDOS_PROTO_ICMP)) return -1;
        if (inet_pton(AF_INET, s->listen_ip, &a4) != 1 && inet_pton(AF_INET6, s->listen_ip, &a6) != 1) return -1;
        for (size_t j = 0; j < i; ++j) if (!strcmp(cfg->services[j].service_id, s->service_id)) return -1;
        for (const char *p = s->service_id; *p; ++p)
            if (!isalnum((unsigned char)*p) && !strchr("_.-", *p)) return -1;
        for (size_t j = 0; j < i; ++j) {
            const antiddos_service_config_t *other = &cfg->services[j];
            uint8_t address[16], other_address[16];
            int family = strchr(s->listen_ip, ':') ? AF_INET6 : AF_INET;
            int same_address = inet_pton(family, s->listen_ip, address) == 1 &&
                inet_pton(family, other->listen_ip, other_address) == 1 &&
                !memcmp(address, other_address, family == AF_INET6 ? 16U : 4U);
            int wildcard = !strcmp(s->listen_ip, "0.0.0.0") || !strcmp(s->listen_ip, "::") ||
                           !strcmp(other->listen_ip, "0.0.0.0") || !strcmp(other->listen_ip, "::");
            if (s->protocol == other->protocol && s->listen_port == other->listen_port &&
                (wildcard || same_address)) return -1;
        }
    }
    return 0;
}

int antiddos_config_load(const char *path, antiddos_config_t *cfg) {
    FILE *fp;
    char line[512];
    size_t line_no = 0;
    antiddos_service_config_t *service = NULL;
    if (!path || !cfg) return -1;
    antiddos_config_defaults(cfg);
    fp = fopen(path, "r");
    if (!fp) return -1;
    while (fgets(line, sizeof(line), fp)) {
        char *p, *eq, *key, *value;
        ++line_no;
        if (!strchr(line, '\n') && !feof(fp)) { fclose(fp); return -1; }
        p = trim(line);
        if (!*p || *p == '#' || *p == ';') continue;
        eq = strchr(p, '=');
        if (!eq) { fclose(fp); return -1; }
        *eq = '\0'; key = trim(p); value = trim(eq + 1);
        if (!strcmp(key, "service")) {
            if (cfg->service_count >= ANTIDDOS_MAX_SERVICES || !*value) { fclose(fp); return -1; }
            service = &cfg->services[cfg->service_count++];
            memset(service, 0, sizeof(*service));
            if (copy_string(service->service_id, sizeof(service->service_id), value) != 0 ||
                copy_string(service->listen_ip, sizeof(service->listen_ip), cfg->listen_ip) != 0) { fclose(fp); return -1; }
            service->protocol = ANTIDDOS_PROTO_TCP;
            continue;
        }
        if (service && (!strncmp(key, "service.", 8) || !strcmp(key, "service_id"))) {
            if (!strcmp(key, "service.listen_ip")) { if (copy_string(service->listen_ip, sizeof(service->listen_ip), value)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "listen_port") || !strcmp(key, "service.listen_port")) { uint32_t v; if (parse_u32(value, &v) || v > 65535U) { fclose(fp); return -1; } service->listen_port = (uint16_t)v; }
            else if (!strcmp(key, "protocol") || !strcmp(key, "service.protocol")) { service->protocol = parse_proto(value); if (!service->protocol) { fclose(fp); return -1; } }
            else if (!strcmp(key, "service.pps_limit")) { if (parse_u64(value, &service->pps_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "service.bps_limit")) { if (parse_u64(value, &service->bps_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "service.connection_limit")) { if (parse_u32(value, &service->connection_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "service_id")) { if (copy_string(service->service_id, sizeof(service->service_id), value)) { fclose(fp); return -1; } }
            else { fclose(fp); return -1; }
            continue;
        }
        {
            uint64_t u64; uint32_t u32; int b;
            if (!strcmp(key, "listen_ip")) { if (copy_string(cfg->listen_ip, sizeof(cfg->listen_ip), value)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "capture_interface")) { if (copy_string(cfg->capture_interface, sizeof(cfg->capture_interface), value)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "listen_port")) { if (parse_u32(value, &u32) || u32 > 65535U) { fclose(fp); return -1; } cfg->listen_port = (uint16_t)u32; }
            else if (!strcmp(key, "pps_limit")) { if (parse_u64(value, &u64)) { fclose(fp); return -1; } cfg->pps_limit = u64; }
            else if (!strcmp(key, "bps_limit")) { if (parse_u64(value, &u64)) { fclose(fp); return -1; } cfg->bps_limit = u64; }
            else if (!strcmp(key, "syn_limit")) { if (parse_u64(value, &u64)) { fclose(fp); return -1; } cfg->syn_limit = u64; }
            else if (!strcmp(key, "udp_limit")) { if (parse_u64(value, &u64)) { fclose(fp); return -1; } cfg->udp_limit = u64; }
            else if (!strcmp(key, "icmp_limit")) { if (parse_u64(value, &u64)) { fclose(fp); return -1; } cfg->icmp_limit = u64; }
            else if (!strcmp(key, "max_connections")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->max_connections = u32; }
            else if (!strcmp(key, "max_connections_per_ip")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->max_connections_per_ip = u32; }
            else if (!strcmp(key, "ip_pps_limit")) { if (parse_u64(value, &cfg->ip_pps_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "ip_bps_limit")) { if (parse_u64(value, &cfg->ip_bps_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "ip_syn_limit")) { if (parse_u32(value, &cfg->ip_syn_limit)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "rate_burst_packets")) { if (parse_u32(value, &cfg->rate_burst_packets)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "capture_batch_packets")) { if (parse_u32(value, &cfg->capture_batch_packets)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "suspicious_threshold")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->suspicious_threshold = u32; }
            else if (!strcmp(key, "attack_threshold")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->attack_threshold = u32; }
            else if (!strcmp(key, "temporary_ban_seconds")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->temporary_ban_seconds = u32; }
            else if (!strcmp(key, "max_ip_entries")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->max_ip_entries = u32; }
            else if (!strcmp(key, "worker_threads")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->worker_threads = u32; }
            else if (!strcmp(key, "max_log_lines_per_second")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->max_log_lines_per_second = u32; }
            else if (!strcmp(key, "management_poll_ms")) { if (parse_u32(value, &u32)) { fclose(fp); return -1; } cfg->management_poll_ms = u32; }
            else if (!strcmp(key, "management_socket")) { if (copy_string(cfg->management_socket, sizeof(cfg->management_socket), value)) { fclose(fp); return -1; } }
            else if (!strcmp(key, "enable_firewall")) { if (parse_bool(value, &b)) { fclose(fp); return -1; } cfg->enable_firewall = b; }
            else { (void)line_no; fclose(fp); return -1; }
        }
    }
    fclose(fp);
    return antiddos_config_validate(cfg);
}

uint32_t antiddos_config_match_service(const antiddos_config_t *cfg, uint8_t protocol,
                                      uint16_t port, const uint8_t *destination, uint8_t address_len) {
    if (!cfg || !destination || (address_len != 4 && address_len != 16)) return 0;
    for (size_t i = 0; i < cfg->service_count; ++i) {
        const antiddos_service_config_t *s = &cfg->services[i];
        if ((uint8_t)s->protocol != protocol && !(s->protocol == ANTIDDOS_PROTO_ICMP && protocol == 58)) continue;
        if (s->protocol != ANTIDDOS_PROTO_ICMP && s->listen_port != port) continue;
        if (!strcmp(s->listen_ip, "0.0.0.0") || !strcmp(s->listen_ip, "::")) return (uint32_t)i + 1;
        uint8_t bytes[16];
        if (inet_pton(address_len == 16 ? AF_INET6 : AF_INET, s->listen_ip, bytes) == 1 &&
            !memcmp(bytes, destination, address_len)) return (uint32_t)i + 1;
    }
    return 0;
}
