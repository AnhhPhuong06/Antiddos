#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#define _POSIX_C_SOURCE 200809L
#include "management.h"
#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

#define CLIENTS 16
#define RESPONSE_SIZE 65536
struct antiddos_management_client {
    int fd;
    char command[1024], response[RESPONSE_SIZE];
    size_t received, written, response_len;
    uint64_t deadline;
};
static uint64_t now_ms(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)ts.tv_nsec / 1000000;
}
static void close_client(antiddos_management_t *m, struct antiddos_management_client *c) {
    if (c->fd >= 0) {
        if (m->network) (void)antiddos_network_remove(m->network, c->fd);
        close(c->fd);
    }
    c->fd = -1;
}
int antiddos_management_init(antiddos_management_t *m, const char *path, antiddos_management_handler handler, void *user) {
    struct sockaddr_un addr = {0}; struct stat existing; mode_t old;
    if (!m || !path || !*path || !handler || strlen(path) >= sizeof(addr.sun_path)) return -1;
    memset(m, 0, sizeof(*m)); m->fd = -1; m->handler = handler; m->user = user;
    addr.sun_family = AF_UNIX; memcpy(addr.sun_path, path, strlen(path) + 1);
    if (!lstat(path, &existing)) {
        if (!S_ISSOCK(existing.st_mode) || existing.st_uid != geteuid()) return -1;
        int probe = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
        if (probe < 0) return -1;
        int result = connect(probe, (struct sockaddr *)&addr, sizeof(addr)); int error = errno; close(probe);
        if (!result || (error != ECONNREFUSED && error != ENOENT)) return -1;
        if (unlink(path)) return -1;
    } else if (errno != ENOENT) return -1;
    m->clients = calloc(CLIENTS, sizeof(*m->clients)); if (!m->clients) return -1;
    for (int i = 0; i < CLIENTS; ++i) m->clients[i].fd = -1;
    m->fd = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
    if (m->fd < 0) { free(m->clients); m->clients = NULL; return -1; }
    old = umask(0077);
    int result = bind(m->fd, (struct sockaddr *)&addr, sizeof(addr)); umask(old);
    if (!result) memcpy(m->path, path, strlen(path) + 1);
    if (result || listen(m->fd, CLIENTS) || chmod(path, 0600)) { antiddos_management_close(m); return -1; }
    return 0;
}
void antiddos_management_attach(antiddos_management_t *m, antiddos_network_t *network) {
    if (m) m->network = network;
}
static void accept_clients(antiddos_management_t *m) {
    for (int n = 0; n < CLIENTS; ++n) {
        int fd = accept4(m->fd, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
        if (fd < 0) return;
        struct antiddos_management_client *c = NULL;
        for (int i = 0; i < CLIENTS; ++i) if (m->clients[i].fd < 0) { c = &m->clients[i]; break; }
        if (!c) { close(fd); continue; }
        memset(c, 0, sizeof(*c)); c->fd = fd; c->deadline = now_ms() + 2000;
        if (m->network && antiddos_network_add(m->network, fd, EPOLLIN | EPOLLRDHUP)) close_client(m, c);
    }
}
int antiddos_management_handle(antiddos_management_t *m, int fd, unsigned int events) {
    if (!m || !m->clients) return 0;
    if (fd == m->fd) { accept_clients(m); return 1; }
    struct antiddos_management_client *c = NULL;
    for (int i = 0; i < CLIENTS; ++i) if (m->clients[i].fd == fd) { c = &m->clients[i]; break; }
    if (!c) return 0;
    if (events & EPOLLERR || now_ms() >= c->deadline) { close_client(m, c); return 1; }
    if (!c->response_len && (events & (EPOLLIN | EPOLLRDHUP | EPOLLHUP))) {
        size_t available = sizeof(c->command) - 1 - c->received;
        ssize_t count = recv(fd, c->command + c->received, available, 0);
        if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) return 1;
        if (count <= 0 || memchr(c->command + c->received, '\0', (size_t)count)) { close_client(m, c); return 1; }
        c->received += (size_t)count; c->command[c->received] = '\0';
        char *newline = strpbrk(c->command, "\r\n");
        if (!newline) { if (c->received == sizeof(c->command) - 1) close_client(m, c); return 1; }
        *newline = '\0';
        if (m->handler(c->command, c->response, sizeof(c->response), m->user) < 0)
            snprintf(c->response, sizeof(c->response), "error\n");
        c->response_len = strnlen(c->response, sizeof(c->response) - 1);
        if (!c->response_len) { c->response[0] = '\n'; c->response_len = 1; }
    }
    if (c->response_len) {
        ssize_t count = send(fd, c->response + c->written, c->response_len - c->written, MSG_NOSIGNAL);
        if (count < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) close_client(m, c);
        else {
            if (count > 0) c->written += (size_t)count;
            if (c->written == c->response_len) close_client(m, c);
            else if (m->network) (void)antiddos_network_modify(m->network, fd, EPOLLOUT | EPOLLRDHUP);
        }
    }
    return 1;
}
int antiddos_management_poll(antiddos_management_t *m, int timeout_ms) {
    struct pollfd fds[CLIENTS + 1]; int count = 1;
    if (!m || m->fd < 0 || !m->clients || timeout_ms < 0 || timeout_ms > 1000) return -1;
    uint64_t now = now_ms();
    fds[0] = (struct pollfd){m->fd, POLLIN, 0};
    for (int i = 0; i < CLIENTS; ++i) {
        struct antiddos_management_client *c = &m->clients[i];
        if (c->fd < 0) continue;
        if (now >= c->deadline) { close_client(m, c); continue; }
        fds[count++] = (struct pollfd){c->fd, c->response_len ? POLLOUT : POLLIN, 0};
    }
    int result = poll(fds, (nfds_t)count, timeout_ms);
    if (result < 0) return errno == EINTR ? 0 : -1;
    for (int i = 0; i < count; ++i) if (fds[i].revents) {
        unsigned int events = 0;
        if (fds[i].revents & POLLIN) events |= EPOLLIN;
        if (fds[i].revents & POLLOUT) events |= EPOLLOUT;
        if (fds[i].revents & POLLHUP) events |= EPOLLHUP;
        if (fds[i].revents & POLLERR) events |= EPOLLERR;
        (void)antiddos_management_handle(m, fds[i].fd, events);
    }
    return 0;
}
void antiddos_management_close(antiddos_management_t *m) {
    if (!m) return;
    if (m->clients) {
        for (int i = 0; i < CLIENTS; ++i) close_client(m, &m->clients[i]);
        free(m->clients); m->clients = NULL;
    }
    if (m->fd >= 0) close(m->fd);
    m->fd = -1;
    if (m->path[0]) { unlink(m->path); m->path[0] = '\0'; }
}
