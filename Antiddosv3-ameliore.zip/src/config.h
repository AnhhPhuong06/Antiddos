#ifndef ANTIDDOS_CONFIG_H
#define ANTIDDOS_CONFIG_H

#include <stddef.h>
#include <stdint.h>

#define ANTIDDOS_MAX_SERVICES 32U
#define ANTIDDOS_MAX_STR 128U

typedef enum {
    ANTIDDOS_PROTO_TCP = 6,
    ANTIDDOS_PROTO_UDP = 17,
    ANTIDDOS_PROTO_ICMP = 1
} antiddos_protocol_t;

typedef struct {
    char service_id[64];
    char listen_ip[64];
    char capture_interface[16]; /* Linux IFNAMSIZ, bounded without platform headers */
    uint16_t listen_port;
    antiddos_protocol_t protocol;
    uint64_t pps_limit;
    uint64_t bps_limit;
    uint32_t connection_limit;
} antiddos_service_config_t;

typedef struct {
    char listen_ip[64];
    char capture_interface[16];
    uint16_t listen_port;
    uint64_t pps_limit;
    uint64_t bps_limit;
    uint64_t syn_limit;
    uint64_t udp_limit;
    uint64_t icmp_limit;
    uint32_t max_connections;
    uint32_t max_connections_per_ip;
    uint64_t ip_pps_limit;
    uint64_t ip_bps_limit;
    uint32_t ip_syn_limit;
    uint32_t rate_burst_packets;
    uint32_t capture_batch_packets;
    uint32_t suspicious_threshold;
    uint32_t attack_threshold;
    uint32_t temporary_ban_seconds;
    uint32_t max_ip_entries;
    uint32_t worker_threads;
    uint32_t max_log_lines_per_second;
    uint32_t management_poll_ms;
    int enable_firewall;
    char management_socket[108];
    antiddos_service_config_t services[ANTIDDOS_MAX_SERVICES];
    size_t service_count;
} antiddos_config_t;

void antiddos_config_defaults(antiddos_config_t *cfg);
int antiddos_config_load(const char *path, antiddos_config_t *cfg);
int antiddos_config_validate(const antiddos_config_t *cfg);
uint32_t antiddos_config_match_service(const antiddos_config_t *cfg, uint8_t protocol,
                                      uint16_t port, const uint8_t *destination, uint8_t address_len);

#endif
