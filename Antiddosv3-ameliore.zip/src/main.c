#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#define _POSIX_C_SOURCE 200809L
#include "config.h"
#include "connection.h"
#include "detector.h"
#include "firewall.h"
#include "logger.h"
#include "management.h"
#include "monitor.h"
#include "network.h"
#include "packet.h"
#include "reputation.h"
#include "utils.h"
#include <arpa/inet.h>
#include <errno.h>
#include <inttypes.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>

#define RECEIVE_BATCH 16
#define FRAME_SIZE 65536
typedef struct {
    antiddos_config_t cfg;
    antiddos_network_t network;
    antiddos_logger_t logger;
    antiddos_firewall_t firewall;
    antiddos_management_t management;
    antiddos_monitor_t monitor;
    detector_t detector;
    reputation_table_t reputation, policy;
    connection_table_t connections;
    int capture_fd, maintenance_fd;
    uint8_t (*frames)[FRAME_SIZE];
    uint64_t capture_drops, table_overflows;
} app_t;

static void append(char *out, size_t length, size_t *used, const char *format, ...) {
    if (*used >= length) return;
    va_list args; va_start(args, format);
    int n = vsnprintf(out + *used, length - *used, format, args); va_end(args);
    if (n < 0) return;
    size_t available = length - *used;
    *used += (size_t)n < available ? (size_t)n : available - 1;
}
static int snapshot(app_t *a, char *out, size_t len) {
    antiddos_monitor_snapshot_t s; antiddos_monitor_snapshot(&a->monitor, &s); size_t used = 0;
    pthread_mutex_lock(&a->firewall.lock); int healthy = a->firewall.healthy; pthread_mutex_unlock(&a->firewall.lock);
    append(out, len, &used, "{\"schema_version\":1,\"timestamp\":%" PRIu64 ",\"dry_run\":%s,\"firewall_healthy\":%s,\"capture_enabled\":%s,\"observed_packets\":%" PRIu64 ",\"observed_bytes\":%" PRIu64 ",\"observed_flagged\":%" PRIu64 ",\"capture_drops\":%" PRIu64 ",\"table_overflows\":%" PRIu64 ",\"ban_count\":%zu,\"observed_connections\":%zu,\"memory_bytes\":%" PRIu64 ",\"cpu_user_usec\":%" PRIu64 ",\"services\":[",
        s.timestamp_sec, a->cfg.enable_firewall ? "false" : "true", healthy ? "true" : "false", a->capture_fd >= 0 ? "true" : "false",
        s.packets, s.bytes, s.dropped_packets, a->capture_drops, a->table_overflows,
        antiddos_firewall_count(&a->firewall), connection_count(&a->connections), s.memory_bytes, s.cpu_user_usec);
    for (size_t i = 0; i < a->cfg.service_count; ++i) {
        const antiddos_service_config_t *c = &a->cfg.services[i]; detector_metric_t m = {0};
        (void)detector_snapshot(&a->detector, (uint32_t)i + 1, &m);
        uint64_t now = antiddos_monotonic_ns();
        if (now >= m.window_start_ns && now - m.window_start_ns >= 1000000000ULL) memset(&m, 0, sizeof(m));
        unsigned risk = (unsigned)m.level;
        if ((m.packets > c->pps_limit || m.bytes > c->bps_limit / 8) && risk < (unsigned)DETECTOR_SUSPICIOUS)
            risk = (unsigned)DETECTOR_SUSPICIOUS;
        append(out, len, &used, "%s{\"id\":%zu,\"name\":\"%s\",\"port\":%u,\"protocol\":\"%s\",\"listen_ip\":\"%s\",\"pps_limit\":%" PRIu64 ",\"bps_limit\":%" PRIu64 ",\"window_packets\":%" PRIu64 ",\"window_bytes\":%" PRIu64 ",\"risk\":%u}",
            i ? "," : "", i + 1, c->service_id, c->listen_port, c->protocol == ANTIDDOS_PROTO_TCP ? "tcp" : c->protocol == ANTIDDOS_PROTO_UDP ? "udp" : "icmp",
            c->listen_ip, c->pps_limit, c->bps_limit, m.packets, m.bytes, risk);
    }
    append(out, len, &used, "],\"blocked\":[");
    pthread_mutex_lock(&a->firewall.lock); size_t shown = 0; uint64_t now = (uint64_t)time(NULL);
    for (size_t i = 0; i < a->firewall.count && shown < 64; ++i) {
        const antiddos_firewall_rule_t *r = &a->firewall.rules[i];
        if (r->trusted || (!r->permanent && r->expires_at <= now)) continue;
        append(out, len, &used, "%s{\"ip\":\"%s\",\"service_id\":%u,\"permanent\":%s,\"remaining_seconds\":%" PRIu64 "}",
            shown++ ? "," : "", r->address, r->service_id, r->permanent ? "true" : "false", r->permanent ? 0 : r->expires_at - now);
    }
    pthread_mutex_unlock(&a->firewall.lock); append(out, len, &used, "]}\n"); return 0;
}
static int management_handler(const char *command, char *response, size_t len, void *user) {
    app_t *a = user; if (!a || !command || !response || !len) return -1;
    if (!strcmp(command, "stats json") || !strcmp(command, "snapshot")) return snapshot(a, response, len);
    if (!strcmp(command, "status") || !strcmp(command, "stats")) {
        antiddos_monitor_snapshot_t s; antiddos_monitor_snapshot(&a->monitor, &s);
        snprintf(response, len, "observed_packets=%" PRIu64 " observed_bytes=%" PRIu64 " observed_flagged=%" PRIu64 " bans=%zu capture_drops=%" PRIu64 " mode=%s\n",
            s.packets, s.bytes, s.dropped_packets, antiddos_firewall_count(&a->firewall), a->capture_drops, a->cfg.enable_firewall ? "kernel-filter" : "dry-run"); return 0;
    }
    if (!strcmp(command, "flush")) { reputation_flush(&a->reputation, false); antiddos_firewall_flush(&a->firewall); snprintf(response, len, "ok: temporary bans cleared; manual policy retained\n"); return 0; }
    if (!strcmp(command, "reload")) { snprintf(response, len, "validated supervisor restart required\n"); return 0; }
    if (!strcmp(command, "list blocked")) {
        size_t used = 0; pthread_mutex_lock(&a->firewall.lock);
        for (size_t i = 0; i < a->firewall.count; ++i) {
            const antiddos_firewall_rule_t *r = &a->firewall.rules[i];
            if (!r->trusted) append(response, len, &used, "%s service=%u permanent=%d\n", r->address, r->service_id, r->permanent);
        }
        pthread_mutex_unlock(&a->firewall.lock); return 0;
    }
    if (!strcmp(command, "list suspicious")) {
        size_t used = 0;
        for (size_t i = 0; i < a->reputation.config.capacity && used + 100 < len; ++i) {
            const reputation_entry_t *e = reputation_at(&a->reputation, i);
            if (e && (e->state == REPUTATION_SUSPECT || e->state == REPUTATION_GREYLIST)) {
                char ip[INET6_ADDRSTRLEN];
                if (inet_ntop(e->key.address_len == 16 ? AF_INET6 : AF_INET, e->key.address, ip, sizeof(ip)))
                    append(response, len, &used, "%s service=%u score=%u\n", ip, e->key.service_id, e->score);
            }
        }
        return 0;
    }
    bool white = !strncmp(command, "whitelist ", 10), black = !strncmp(command, "blacklist ", 10);
    if (white || black) {
        bool add = !strncmp(command + 10, "add ", 4), remove = !strncmp(command + 10, "remove ", 7);
        if (!add && !remove) return -1;
        const char *ip = command + (add ? 14 : 17); uint8_t bytes[16], n = 0; char canonical_ip[INET6_ADDRSTRLEN];
        if (inet_pton(AF_INET, ip, bytes) == 1) n = 4;
        else if (inet_pton(AF_INET6, ip, bytes) == 1) n = 16;
        if (!n || !inet_ntop(n == 16 ? AF_INET6 : AF_INET, bytes, canonical_ip, sizeof(canonical_ip))) return -1;
        reputation_key_t key; reputation_key(&key, 0, bytes, n);
        uint64_t now = antiddos_monotonic_ns();
        reputation_entry_t *entry = reputation_get(&a->policy, &key, now, add);
        if (!entry && remove) { snprintf(response, len, "ok: policy already absent\n"); return 0; }
        if (!entry) { snprintf(response, len, "error: policy table full\n"); return -1; }
        reputation_entry_t previous = *entry;
        bool next_white = white ? add : (add ? false : previous.whitelist);
        bool next_black = black ? add : (add ? false : previous.blacklist);
        if (reputation_set_policy(&a->policy, &key, next_white, false, next_black, now)) return -1;
        int result;
        if (white) result = antiddos_firewall_set_trusted(&a->firewall, canonical_ip, add);
        else if (add) {
            antiddos_firewall_set_trusted(&a->firewall, canonical_ip, 0);
            result = antiddos_firewall_add(&a->firewall, canonical_ip, 0, 1);
        } else { result = antiddos_firewall_remove(&a->firewall, canonical_ip); if (result == -1) result = 0; }
        if (result) *entry = previous;
        snprintf(response, len, "%s\n", result ? "error: policy queue full" : "ok: policy queued"); return result;
    }
    snprintf(response, len, "commands: status stats stats json list blocked list suspicious flush reload whitelist add/remove <ip> blacklist add/remove <ip>\n"); return 0;
}
static void process_packet(app_t *a, const uint8_t *frame, size_t length, uint64_t now) {
    packet_view_t p; packet_result_t result = packet_parse(frame, length, &p);
    if (result != PACKET_OK) {
        if (result != PACKET_ERR_UNSUPPORTED) antiddos_monitor_record_packet(&a->monitor, 0, length, 0, 1);
        return;
    }
    uint32_t service = antiddos_config_match_service(&a->cfg, p.protocol, p.dst_port, p.dst_addr, p.addr_len);
    if (!service) return;
    bool syn = p.protocol == PACKET_PROTO_TCP && (p.tcp_flags & 0x12U) == 0x02U;
    reputation_key_t global; reputation_key(&global, 0, p.src_addr, p.addr_len);
    reputation_entry_t *policy = reputation_get(&a->policy, &global, now, false);
    bool trusted = policy && (policy->whitelist || policy->trusted);
    if (policy && policy->blacklist) { antiddos_monitor_record_packet(&a->monitor, p.protocol, length, syn, 1); return; }
    bool new_connection = false;
    if (p.protocol == PACKET_PROTO_TCP) {
        connection_key_t key = {0}; key.service_id = service; key.protocol = p.protocol;
        key.src_port = p.src_port; key.dst_port = p.dst_port; key.address_len = p.addr_len; memcpy(key.address, p.src_addr, p.addr_len);
        if (p.tcp_flags & 0x05U) (void)connection_close(&a->connections, &key);
        else if (syn) { int rc = connection_open(&a->connections, &key, now); new_connection = rc == 0; if (rc == -2) ++a->table_overflows; }
        else (void)connection_touch(&a->connections, &key, now);
        if (new_connection) antiddos_monitor_record_connection(&a->monitor);
    }
    detector_event_t event = {0}; event.service_id = service; event.protocol = p.protocol;
    event.tcp_flags = p.tcp_flags; event.bytes = length; event.source_len = p.addr_len;
    memcpy(event.source, p.src_addr, p.addr_len); event.new_connection = new_connection;
    (void)detector_observe(&a->detector, &event, now, NULL);
    reputation_key_t key; reputation_key(&key, service, p.src_addr, p.addr_len);
    reputation_entry_t *entry = reputation_get(&a->reputation, &key, now, true);
    if (!entry) { ++a->table_overflows; antiddos_monitor_record_packet(&a->monitor, p.protocol, length, syn, 0); return; }
    bool was_blocked = reputation_is_blocked(&a->reputation, entry, now);
    reputation_observe_packet(entry, length, new_connection, syn, now);
    bool bad_flags = p.protocol == PACKET_PROTO_TCP && ((p.tcp_flags & 0x03U) == 0x03U || (p.tcp_flags & 0x06U) == 0x06U);
    bool excessive = entry->window_packets > a->cfg.ip_pps_limit || entry->window_bytes > a->cfg.ip_bps_limit / 8 || entry->window_syn > a->cfg.ip_syn_limit;
    if (!trusted && !was_blocked && !entry->window_violation && (excessive || bad_flags)) {
        entry->window_violation = true;
        reputation_violate(&a->reputation, entry, a->cfg.attack_threshold, now);
    }
    bool blocked = !trusted && reputation_is_blocked(&a->reputation, entry, now);
    if (blocked && !was_blocked) {
        char ip[INET6_ADDRSTRLEN];
        if (inet_ntop(p.addr_len == 16 ? AF_INET6 : AF_INET, p.src_addr, ip, sizeof(ip)) &&
            antiddos_firewall_add_service(&a->firewall, ip, service, a->cfg.temporary_ban_seconds)) ++a->table_overflows;
    }
    antiddos_monitor_record_packet(&a->monitor, p.protocol, length, syn, !trusted && (excessive || bad_flags || blocked));
}
static int event_callback(int fd, uint32_t events, void *user) {
    app_t *a = user;
    if (antiddos_management_handle(&a->management, fd, events)) return 0;
    if (fd == a->maintenance_fd) {
        uint64_t ticks; (void)read(fd, &ticks, sizeof(ticks)); uint64_t now = antiddos_monotonic_ns();
        reputation_cleanup(&a->reputation, now, 1024); reputation_cleanup(&a->policy, now, 1024);
        connection_cleanup(&a->connections, now, 1024);
        antiddos_firewall_expire(&a->firewall, (uint64_t)time(NULL)); (void)antiddos_management_poll(&a->management, 0);
        if (a->capture_fd >= 0) {
            struct tpacket_stats stats; socklen_t len = sizeof(stats);
            if (!getsockopt(a->capture_fd, SOL_PACKET, PACKET_STATISTICS, &stats, &len)) a->capture_drops += stats.tp_drops;
        }
        return 0;
    }
    if (fd != a->capture_fd || !(events & EPOLLIN)) return 0;
    struct mmsghdr messages[RECEIVE_BATCH]; struct iovec buffers[RECEIVE_BATCH];
    for (uint32_t processed = 0; processed < a->cfg.capture_batch_packets && !a->network.stop;) {
        unsigned count = a->cfg.capture_batch_packets - processed;
        if (count > RECEIVE_BATCH) count = RECEIVE_BATCH;
        memset(messages, 0, sizeof(messages));
        for (unsigned i = 0; i < count; ++i) {
            buffers[i] = (struct iovec){a->frames[i], FRAME_SIZE};
            messages[i].msg_hdr.msg_iov = &buffers[i]; messages[i].msg_hdr.msg_iovlen = 1;
        }
        int received = recvmmsg(fd, messages, count, MSG_DONTWAIT, NULL);
        if (received < 0) { if (errno == EINTR) continue; break; }
        if (!received) break;
        uint64_t now = antiddos_monotonic_ns();
        for (int i = 0; i < received; ++i) process_packet(a, a->frames[i], messages[i].msg_len, now);
        processed += (uint32_t)received;
    }
    return 0;
}
static void cleanup(app_t *a) {
    antiddos_network_stop(&a->network);
    if (a->capture_fd >= 0) close(a->capture_fd);
    if (a->maintenance_fd >= 0) close(a->maintenance_fd);
    antiddos_management_close(&a->management); antiddos_firewall_close(&a->firewall);
    connection_destroy(&a->connections); reputation_destroy(&a->reputation); reputation_destroy(&a->policy);
    detector_destroy(&a->detector); antiddos_network_close(&a->network); antiddos_logger_close(&a->logger); free(a->frames);
}
int main(int argc, char **argv) {
    bool print_policy = argc > 1 && !strcmp(argv[1], "--print-firewall");
    bool check = argc > 1 && !strcmp(argv[1], "--check-config");
    if (argc > 1 && !strcmp(argv[1], "--help")) { puts("antiddos [config]\nantiddos --check-config [config]\nantiddos --print-firewall [config]"); return 0; }
    const char *path = argc > (print_policy || check ? 2 : 1) ? argv[print_policy || check ? 2 : 1] : "config/antiddos.conf";
    app_t *a = calloc(1, sizeof(*a)); if (!a) return EXIT_FAILURE;
    a->capture_fd = a->maintenance_fd = a->network.epoll_fd = a->management.fd = -1;
    if (antiddos_config_load(path, &a->cfg)) { fprintf(stderr, "invalid config: %s\n", path); free(a); return EXIT_FAILURE; }
    if (print_policy || check) {
        int result = print_policy ? antiddos_firewall_write_policy(stdout, &a->cfg) : 0;
        if (check) printf("configuration valid: %zu services\n", a->cfg.service_count);
        free(a); return result ? EXIT_FAILURE : EXIT_SUCCESS;
    }
    if (antiddos_logger_init(&a->logger, "stderr", ANTIDDOS_LOG_INFO, a->cfg.max_log_lines_per_second)) { free(a); return EXIT_FAILURE; }
    detector_config_t dc = {ANTIDDOS_MAX_SERVICES, 1000000000ULL, a->cfg.pps_limit, a->cfg.bps_limit, a->cfg.syn_limit, a->cfg.udp_limit, a->cfg.icmp_limit, a->cfg.suspicious_threshold, a->cfg.attack_threshold};
    reputation_config_t rc = {a->cfg.max_ip_entries, 300000000000ULL, 1000000000ULL, a->cfg.suspicious_threshold,
        a->cfg.attack_threshold - 1, a->cfg.attack_threshold, (uint64_t)a->cfg.temporary_ban_seconds * 1000000000ULL, 3600000000000ULL, 2};
    reputation_config_t policies = rc; policies.capacity = ANTIDDOS_FIREWALL_MAX_RULES; policies.idle_ttl_ns = 1000000000ULL;
    a->frames = calloc(RECEIVE_BATCH, FRAME_SIZE);
    if (!a->frames || detector_init(&a->detector, &dc) || reputation_init(&a->reputation, &rc) || reputation_init(&a->policy, &policies) ||
        connection_init(&a->connections, a->cfg.max_connections, 300000000000ULL) ||
        antiddos_firewall_init(&a->firewall, a->cfg.enable_firewall, "antiddos", "blocked") || antiddos_network_init(&a->network, 64)) {
        cleanup(a); free(a); return EXIT_FAILURE;
    }
    antiddos_monitor_init(&a->monitor);
    if (antiddos_network_install_signals(&a->network) || antiddos_management_init(&a->management, a->cfg.management_socket, management_handler, a)) {
        ANTIDDOS_LOG(&a->logger, ANTIDDOS_LOG_ERROR, "management_failed", "socket=%s", a->cfg.management_socket); cleanup(a); free(a); return EXIT_FAILURE;
    }
    antiddos_management_attach(&a->management, &a->network);
    if (antiddos_network_add(&a->network, a->management.fd, EPOLLIN) || antiddos_firewall_start(&a->firewall, &a->cfg)) {
        ANTIDDOS_LOG(&a->logger, ANTIDDOS_LOG_ERROR, "firewall_start_failed", "kernel policy could not be installed"); cleanup(a); free(a); return EXIT_FAILURE;
    }
    a->maintenance_fd = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC);
    struct itimerspec timer = {{1, 0}, {1, 0}};
    if (a->maintenance_fd < 0 || timerfd_settime(a->maintenance_fd, 0, &timer, NULL) || antiddos_network_add(&a->network, a->maintenance_fd, EPOLLIN)) { cleanup(a); free(a); return EXIT_FAILURE; }
    if (a->cfg.capture_interface[0]) {
        a->capture_fd = antiddos_network_open_packet(&a->network, a->cfg.capture_interface, ETH_P_ALL);
        if (a->capture_fd < 0) ANTIDDOS_LOG(&a->logger, ANTIDDOS_LOG_WARNING, "capture_unavailable", "interface=%s kernel_filter=%d", a->cfg.capture_interface, a->cfg.enable_firewall);
    }
    ANTIDDOS_LOG(&a->logger, ANTIDDOS_LOG_INFO, "started", "services=%zu kernel_filter=%d capture=%s", a->cfg.service_count, a->cfg.enable_firewall, a->capture_fd >= 0 ? "enabled" : "disabled");
    int result = antiddos_network_run(&a->network, 1000, event_callback, a);
    cleanup(a); free(a); return result ? EXIT_FAILURE : EXIT_SUCCESS;
}
