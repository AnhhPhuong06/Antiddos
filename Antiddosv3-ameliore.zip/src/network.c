#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#define _POSIX_C_SOURCE 200809L
#include "network.h"
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <net/if.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <unistd.h>

static antiddos_network_t *signal_net;

static void on_signal(int signo) {
    (void)signo;
    if (signal_net) signal_net->stop = 1;
}

int antiddos_network_init(antiddos_network_t *net, size_t max_events) {
    struct epoll_event *events;
    if (!net || max_events == 0 || max_events > 65536U) return -1;
    net->epoll_fd = epoll_create1(EPOLL_CLOEXEC);
    if (net->epoll_fd < 0) return -1;
    events = calloc(max_events, sizeof(*events));
    if (!events) { close(net->epoll_fd); net->epoll_fd = -1; return -1; }
    net->events = events;
    net->max_events = max_events;
    net->stop = 0;
    return 0;
}

void antiddos_network_close(antiddos_network_t *net) {
    if (!net) return;
    if (net->epoll_fd >= 0) close(net->epoll_fd);
    free(net->events);
    if (signal_net == net) signal_net = NULL;
    net->epoll_fd = -1; net->events = NULL; net->max_events = 0;
}

int antiddos_network_set_nonblocking(int fd) {
    int flags;
    if (fd < 0) return -1;
    flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) return -1;
    return 0;
}

int antiddos_network_open_packet(antiddos_network_t *net, const char *ifname, uint16_t ethertype) {
    int fd;
    struct sockaddr_ll addr;
    unsigned int ifindex;
    if (!net || net->epoll_fd < 0 || !ifname || !*ifname || strlen(ifname) >= IFNAMSIZ) return -1;
    ifindex = if_nametoindex(ifname);
    if (!ifindex) return -1;
    fd = socket(AF_PACKET, SOCK_RAW | SOCK_NONBLOCK | SOCK_CLOEXEC, htons(ethertype));
    if (fd < 0) return -1;
    { int bytes = 4 * 1024 * 1024; (void)setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &bytes, sizeof(bytes)); }
    memset(&addr, 0, sizeof(addr));
    addr.sll_family = AF_PACKET;
    addr.sll_protocol = htons(ethertype);
    addr.sll_ifindex = (int)ifindex;
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 ||
        antiddos_network_add(net, fd, EPOLLIN | EPOLLRDHUP) != 0) { close(fd); return -1; }
    {
#ifdef PACKET_IGNORE_OUTGOING
        int ignore_outgoing = 1;
        (void)setsockopt(fd, SOL_PACKET, PACKET_IGNORE_OUTGOING, &ignore_outgoing, sizeof(ignore_outgoing));
#endif
    }
    return fd;
}

int antiddos_network_add(antiddos_network_t *net, int fd, uint32_t events) {
    struct epoll_event ev;
    if (!net || net->epoll_fd < 0 || fd < 0) return -1;
    if (antiddos_network_set_nonblocking(fd) != 0) return -1;
    ev.events = events; ev.data.fd = fd;
    return epoll_ctl(net->epoll_fd, EPOLL_CTL_ADD, fd, &ev);
}

int antiddos_network_modify(antiddos_network_t *net, int fd, uint32_t events) {
    struct epoll_event ev;
    if (!net || net->epoll_fd < 0 || fd < 0) return -1;
    ev.events = events; ev.data.fd = fd;
    return epoll_ctl(net->epoll_fd, EPOLL_CTL_MOD, fd, &ev);
}

int antiddos_network_remove(antiddos_network_t *net, int fd) {
    if (!net || net->epoll_fd < 0 || fd < 0) return -1;
    return epoll_ctl(net->epoll_fd, EPOLL_CTL_DEL, fd, NULL);
}

int antiddos_network_run(antiddos_network_t *net, int timeout_ms,
                         antiddos_network_callback callback, void *user) {
    struct epoll_event *events;
    if (!net || net->epoll_fd < 0 || !callback || !net->events) return -1;
    events = (struct epoll_event *)net->events;
    while (!net->stop) {
        int n = epoll_wait(net->epoll_fd, events, (int)net->max_events, timeout_ms);
        int i;
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        for (i = 0; i < n && !net->stop; ++i) {
            int rc = callback(events[i].data.fd, events[i].events, user);
            if (rc < 0) return rc;
        }
    }
    return 0;
}

void antiddos_network_stop(antiddos_network_t *net) { if (net) net->stop = 1; }

int antiddos_network_open_capture(const char *interface_name, int promiscuous) {
    int fd; struct sockaddr_ll addr; struct packet_mreq mr;
    unsigned int ifindex;
    if (!interface_name || !*interface_name || strlen(interface_name) >= IFNAMSIZ) return -1;
    ifindex = if_nametoindex(interface_name); if (ifindex == 0) return -1;
    fd = socket(AF_PACKET, SOCK_RAW | SOCK_CLOEXEC, htons(ETH_P_ALL)); if (fd < 0) return -1;
    memset(&addr, 0, sizeof(addr)); addr.sll_family = AF_PACKET; addr.sll_protocol = htons(ETH_P_ALL); addr.sll_ifindex = (int)ifindex;
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) { close(fd); return -1; }
    if (promiscuous) { memset(&mr, 0, sizeof(mr)); mr.mr_ifindex = (int)ifindex; mr.mr_type = PACKET_MR_PROMISC; (void)setsockopt(fd, SOL_PACKET, PACKET_ADD_MEMBERSHIP, &mr, sizeof(mr)); }
    if (antiddos_network_set_nonblocking(fd) != 0) { close(fd); return -1; }
    return fd;
}

int antiddos_network_install_signals(antiddos_network_t *net) {
    struct sigaction sa;
    if (!net) return -1;
    signal_net = net;
    sigemptyset(&sa.sa_mask); sa.sa_flags = 0; sa.sa_handler = on_signal;
    if (sigaction(SIGINT, &sa, NULL) != 0 || sigaction(SIGTERM, &sa, NULL) != 0) return -1;
    signal(SIGPIPE, SIG_IGN);
    return 0;
}
