#ifndef ANTIDDOS_FIREWALL_H
#define ANTIDDOS_FIREWALL_H

#include <pthread.h>
#include <stddef.h>
#include <stdint.h>
#include <netinet/in.h>
#include <stdio.h>
#include "config.h"

#define ANTIDDOS_FIREWALL_MAX_RULES 4096U

typedef struct {
    char address[INET6_ADDRSTRLEN];
    uint64_t expires_at;
    int permanent;
    uint32_t service_id;
    int trusted;
} antiddos_firewall_rule_t;

typedef struct {
    char table[32];
    char set_name[32]; /* backwards-compatible alias for IPv4 set */
    char set_name_v6[32];
    int enabled;
    int dirty;
    uint64_t generation;
    size_t count;
    antiddos_firewall_rule_t rules[ANTIDDOS_FIREWALL_MAX_RULES];
    pthread_mutex_t lock;
    pthread_cond_t changed;
    pthread_t worker;
    antiddos_config_t config;
    int worker_ready, stopping, healthy;
    int lock_ready;
} antiddos_firewall_t;

int antiddos_firewall_init(antiddos_firewall_t *fw, int enabled,
                           const char *table, const char *set_name);
void antiddos_firewall_close(antiddos_firewall_t *fw);
int antiddos_firewall_add(antiddos_firewall_t *fw, const char *address,
                          uint32_t ttl_seconds, int permanent);
int antiddos_firewall_add_service(antiddos_firewall_t *fw, const char *address,
                                  uint32_t service_id, uint32_t ttl_seconds);
int antiddos_firewall_set_trusted(antiddos_firewall_t *fw, const char *address, int trusted);
int antiddos_firewall_start(antiddos_firewall_t *fw, const antiddos_config_t *cfg);
int antiddos_firewall_write_policy(FILE *output, const antiddos_config_t *cfg);
int antiddos_firewall_remove(antiddos_firewall_t *fw, const char *address);
size_t antiddos_firewall_expire(antiddos_firewall_t *fw, uint64_t now);
int antiddos_firewall_flush(antiddos_firewall_t *fw);
/* Apply pending userspace changes to nftables. Call from a control/maintenance thread,
 * never from packet processing. It is a no-op when enabled=0. */
int antiddos_firewall_sync(antiddos_firewall_t *fw);
size_t antiddos_firewall_count(const antiddos_firewall_t *fw);

#endif
