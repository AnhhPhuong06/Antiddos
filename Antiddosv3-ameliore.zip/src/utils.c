#define _POSIX_C_SOURCE 200809L
#include "utils.h"
#include <stdio.h>
#include <string.h>
#include <time.h>

uint64_t antiddos_monotonic_ns(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

uint64_t antiddos_saturating_add_u64(uint64_t left, uint64_t right) {
    return right > UINT64_MAX - left ? UINT64_MAX : left + right;
}

int antiddos_copy_string(char *destination, size_t destination_size, const char *source) {
    int written;
    if (!destination || !source || destination_size == 0) return -1;
    written = snprintf(destination, destination_size, "%s", source);
    return written < 0 || (size_t)written >= destination_size ? -1 : 0;
}
