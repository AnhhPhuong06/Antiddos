#include "packet.h"

#include <string.h>

static uint16_t be16(const uint8_t *p) {
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}
static bool span_ok(size_t off, size_t need, size_t len) {
    return off <= len && need <= len - off;
}

packet_result_t packet_parse(const uint8_t *frame, size_t frame_len,
                             packet_view_t *out) {
    size_t off, l3_len, total_len, l4off, l4len, payload_off;
    uint16_t ethertype;
    uint8_t next;
    uint16_t frag;
    bool nonfirst_fragment = false;
    if (frame == NULL || out == NULL) return PACKET_ERR_ARGUMENT;
    memset(out, 0, sizeof(*out));
    out->frame_len = frame_len;
    if (frame_len < 14) return PACKET_ERR_TRUNCATED;
    ethertype = be16(frame + 12);
    off = 14;
    /* Accept one or more VLAN tags, with a conservative bound. */
    for (unsigned int tags = 0; tags < 4 &&
         (ethertype == 0x8100 || ethertype == 0x88a8 || ethertype == 0x9100); ++tags) {
        if (!span_ok(off, 4, frame_len)) return PACKET_ERR_TRUNCATED;
        ethertype = be16(frame + off + 2);
        off += 4;
    }
    out->ethertype = ethertype;
    out->network_offset = off;
    if (ethertype == 0x0800) {
        uint8_t vihl;
        if (!span_ok(off, 20, frame_len)) return PACKET_ERR_TRUNCATED;
        vihl = frame[off];
        if ((vihl >> 4) != 4) return PACKET_ERR_MALFORMED;
        l3_len = (size_t)(vihl & 0x0f) * 4U;
        if (l3_len < 20 || !span_ok(off, l3_len, frame_len)) return PACKET_ERR_MALFORMED;
        total_len = be16(frame + off + 2);
        if (total_len < l3_len || total_len > frame_len - off)
            return PACKET_ERR_MALFORMED;
        memcpy(out->src_addr, frame + off + 12, 4);
        memcpy(out->dst_addr, frame + off + 16, 4);
        out->addr_len = 4;
        out->ipv6 = false;
        next = frame[off + 9];
        frag = be16(frame + off + 6);
        out->fragmented = ((frag & 0x1fffU) != 0U) || ((frag & 0x2000U) != 0U);
        nonfirst_fragment = (frag & 0x1fffU) != 0U;
        l4off = off + l3_len;
        l3_len = total_len;
    } else if (ethertype == 0x86dd) {
        unsigned int ext_count = 0;
        if (!span_ok(off, 40, frame_len)) return PACKET_ERR_TRUNCATED;
        if ((frame[off] >> 4) != 6) return PACKET_ERR_MALFORMED;
        total_len = (size_t)be16(frame + off + 4) + 40U;
        if (total_len < 40 || total_len > frame_len - off)
            return PACKET_ERR_MALFORMED;
        memcpy(out->src_addr, frame + off + 8, 16);
        memcpy(out->dst_addr, frame + off + 24, 16);
        out->addr_len = 16;
        out->ipv6 = true;
        next = frame[off + 6];
        l4off = off + 40;
        /* Walk common extension headers, bounded to prevent parser abuse. */
        while (next == 0 || next == 43 || next == 44 || next == 51 || next == 60) {
            size_t hlen;
            if (++ext_count > 8 || !span_ok(l4off, 2, off + total_len))
                return PACKET_ERR_MALFORMED;
            if (next == 44) {
                hlen = 8;
                if (!span_ok(l4off, hlen, off + total_len)) return PACKET_ERR_MALFORMED;
                frag = be16(frame + l4off + 2);
                out->fragmented = ((frag & 0xfff9U) != 0U);
                nonfirst_fragment = (frag & 0xfff8U) != 0U;
            } else if (next == 51) {
                hlen = ((size_t)frame[l4off + 1] + 2U) * 4U;
                if (!span_ok(l4off, hlen, off + total_len)) return PACKET_ERR_MALFORMED;
            } else {
                hlen = ((size_t)frame[l4off + 1] + 1U) * 8U;
                if (!span_ok(l4off, hlen, off + total_len)) return PACKET_ERR_MALFORMED;
            }
            next = frame[l4off];
            l4off += hlen;
        }
        l3_len = total_len;
    } else {
        return PACKET_ERR_UNSUPPORTED;
    }
    out->protocol = next;
    out->ip_header_len = (uint16_t)(l4off - off);
    /* Non-first fragments do not contain a trustworthy transport header. */
    if (nonfirst_fragment) {
        out->transport_offset = l4off;
        out->payload_offset = l4off;
        out->payload_len = (off + l3_len) - l4off;
        return PACKET_OK;
    }
    if (l4off > off + l3_len) return PACKET_ERR_MALFORMED;
    l4len = 0;
    if (next == PACKET_PROTO_TCP) {
        if (!span_ok(l4off, 20, off + l3_len)) return PACKET_ERR_TRUNCATED;
        out->src_port = be16(frame + l4off);
        out->dst_port = be16(frame + l4off + 2);
        l4len = (size_t)((frame[l4off + 12] >> 4) & 0x0fU) * 4U;
        if (l4len < 20 || !span_ok(l4off, l4len, off + l3_len)) return PACKET_ERR_MALFORMED;
        out->tcp_flags = frame[l4off + 13];
    } else if (next == PACKET_PROTO_UDP) {
        uint16_t declared;
        if (!span_ok(l4off, 8, off + l3_len)) return PACKET_ERR_TRUNCATED;
        out->src_port = be16(frame + l4off);
        out->dst_port = be16(frame + l4off + 2);
        declared = be16(frame + l4off + 4);
        if (declared < 8 || declared > (off + l3_len - l4off)) return PACKET_ERR_MALFORMED;
        l4len = 8;
        /* UDP length bounds payload; trailing L3 padding is ignored. */
        l3_len = (l4off - off) + declared;
    } else if (next == PACKET_PROTO_ICMP || next == PACKET_PROTO_ICMPV6) {
        if (!span_ok(l4off, 4, off + l3_len)) return PACKET_ERR_TRUNCATED;
        l4len = (next == PACKET_PROTO_ICMP) ? 8 : 4;
        if (!span_ok(l4off, l4len, off + l3_len)) return PACKET_ERR_MALFORMED;
    } else {
        /* Unknown L4 protocols are valid; expose their payload safely. */
        l4len = 0;
    }
    payload_off = l4off + l4len;
    if (payload_off > off + l3_len) return PACKET_ERR_MALFORMED;
    out->transport_offset = l4off;
    out->l4_header_len = (uint16_t)l4len;
    out->payload_offset = payload_off;
    out->payload_len = (off + l3_len) - payload_off;
    return PACKET_OK;
}
