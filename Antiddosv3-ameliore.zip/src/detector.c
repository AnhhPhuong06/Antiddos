#define _POSIX_C_SOURCE 200809L
#include "detector.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

static uint64_t add_sat(uint64_t a, uint64_t b) { return b > UINT64_MAX - a ? UINT64_MAX : a + b; }
static size_t service_index(const detector_t *d, uint32_t id) {
    /* Service identifiers are normally dense; bounded linear lookup keeps the
     * table deterministic and caps attacker-controlled allocation. */
    for (size_t i = 0; i < d->service_count; ++i) {
        if (d->services[i].service_id == id) return i;
    }
    return SIZE_MAX;
}

int detector_init(detector_t *d, const detector_config_t *c) {
    pthread_mutex_t *m;
    if (!d || !c || c->max_services == 0 || c->max_services > 4096 ||
        c->window_ns == 0 || c->pps_limit == 0 || c->bps_limit == 0 ||
        c->suspicious_threshold == 0 || c->attack_threshold <= c->suspicious_threshold) return -1;
    memset(d, 0, sizeof(*d));
    d->services = calloc(c->max_services, sizeof(*d->services));
    m = calloc(1, sizeof(*m));
    if (!d->services || !m || pthread_mutex_init(m, NULL) != 0) {
        free(d->services); free(m); memset(d, 0, sizeof(*d)); return -1;
    }
    d->config = *c; d->lock = m; return 0;
}

void detector_destroy(detector_t *d) {
    if (!d) return;
    if (d->lock) { pthread_mutex_destroy((pthread_mutex_t *)d->lock); free(d->lock); }
    free(d->services); memset(d, 0, sizeof(*d));
}

static void roll_window(const detector_t *d, detector_metric_t *m, uint32_t id, uint64_t now) {
    /* A zero timestamp is valid; the caller creates a metric with its window
     * start set, so only move windows on clock rollback or elapsed duration. */
    if (now < m->window_start_ns || now - m->window_start_ns >= d->config.window_ns) {
        memset(m, 0, sizeof(*m));
        m->service_id = id;
        m->window_start_ns = now;
    }
}

detector_level_t detector_observe(detector_t *d, const detector_event_t *e,
                                  uint64_t now, uint32_t *score_out) {
    detector_metric_t *m; size_t idx; uint32_t score = 0;
    if (!d || !d->lock || !e || e->source_len > sizeof(e->source) || e->bytes > UINT64_MAX - 1) return DETECTOR_HIGH_RISK;
    pthread_mutex_lock((pthread_mutex_t *)d->lock);
    idx = service_index(d, e->service_id);
    if (idx == SIZE_MAX) {
        if (d->service_count >= d->config.max_services) { pthread_mutex_unlock((pthread_mutex_t *)d->lock); return DETECTOR_ATTACK; }
        idx = d->service_count++;
        memset(&d->services[idx], 0, sizeof(d->services[idx]));
        d->services[idx].service_id = e->service_id;
        d->services[idx].window_start_ns = now;
    }
    m = &d->services[idx];
    roll_window(d, m, e->service_id, now);
    m->packets = add_sat(m->packets, 1); m->bytes = add_sat(m->bytes, e->bytes);
    if (e->new_connection) m->connections = add_sat(m->connections, 1);
    if (e->protocol == PACKET_PROTO_UDP) m->udp = add_sat(m->udp, 1);
    if (e->protocol == PACKET_PROTO_ICMP || e->protocol == PACKET_PROTO_ICMPV6) m->icmp = add_sat(m->icmp, 1);
    if (e->protocol == PACKET_PROTO_TCP && (e->tcp_flags & 0x02U) != 0 && (e->tcp_flags & 0x10U) == 0) m->syn = add_sat(m->syn, 1);
    if (e->protocol == PACKET_PROTO_TCP && (e->tcp_flags & 0x10U) != 0) m->ack = add_sat(m->ack, 1);
    if (e->protocol == PACKET_PROTO_TCP && (e->tcp_flags & 0x04U) != 0) m->rst = add_sat(m->rst, 1);
    if (e->protocol == PACKET_PROTO_TCP && (e->tcp_flags & 0x01U) != 0) m->fin = add_sat(m->fin, 1);
    if (m->packets > d->config.pps_limit) score += 30;
    /* bps_limit is configured in bits/sec; a one-second window compares
     * against the corresponding byte budget without overflowing. */
    uint64_t byte_limit = d->config.bps_limit / 8U;
    if (byte_limit == 0) byte_limit = 1;
    if (m->bytes > byte_limit) score += 30;
    if (m->syn > d->config.syn_limit) score += 20;
    if (m->udp > d->config.udp_limit) score += 20;
    if (m->icmp > d->config.icmp_limit) score += 15;
    if ((e->protocol == PACKET_PROTO_TCP) && ((e->tcp_flags & 0x01U) && (e->tcp_flags & 0x02U))) score += 20;
    if (score > UINT32_MAX - m->score) m->score = UINT32_MAX; else m->score += score;
    /* attack_threshold is the high-risk boundary; attack requires a score at
     * least twice that value. This leaves a useful suspicious band for normal
     * threshold crossings while retaining escalation. */
    uint32_t attack_score = d->config.attack_threshold > UINT32_MAX / 2U ? UINT32_MAX : d->config.attack_threshold * 2U;
    if (m->score >= attack_score) m->level = DETECTOR_ATTACK;
    else if (m->score >= d->config.attack_threshold) m->level = DETECTOR_HIGH_RISK;
    else if (m->score >= d->config.suspicious_threshold) m->level = DETECTOR_SUSPICIOUS;
    else m->level = DETECTOR_NORMAL;
    if (score_out) *score_out = m->score;
    detector_level_t level = m->level;
    pthread_mutex_unlock((pthread_mutex_t *)d->lock); return level;
}

int detector_snapshot(const detector_t *d, uint32_t service_id, detector_metric_t *out) {
    if (!d || !d->lock || !out) return -1;
    pthread_mutex_lock((pthread_mutex_t *)d->lock);
    size_t idx = service_index(d, service_id);
    if (idx == SIZE_MAX) { pthread_mutex_unlock((pthread_mutex_t *)d->lock); return -1; }
    *out = d->services[idx];
    pthread_mutex_unlock((pthread_mutex_t *)d->lock); return 0;
}

void detector_reset(detector_t *d) {
    if (!d || !d->lock) return;
    pthread_mutex_lock((pthread_mutex_t *)d->lock);
    memset(d->services, 0, d->config.max_services * sizeof(*d->services)); d->service_count = 0;
    pthread_mutex_unlock((pthread_mutex_t *)d->lock);
}
