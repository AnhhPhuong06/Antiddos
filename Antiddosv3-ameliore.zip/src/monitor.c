#define _POSIX_C_SOURCE 200809L
#include "monitor.h"
#include <inttypes.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <unistd.h>

void antiddos_monitor_init(antiddos_monitor_t *monitor) {
    if (monitor) memset(monitor, 0, sizeof(*monitor));
}

void antiddos_monitor_record_packet(antiddos_monitor_t *monitor, uint8_t protocol,
                                    uint64_t bytes, int syn, int dropped) {
    if (!monitor) return;
    atomic_fetch_add_explicit(&monitor->packets, 1, memory_order_relaxed);
    atomic_fetch_add_explicit(&monitor->bytes, bytes, memory_order_relaxed);
    if (protocol == 6) atomic_fetch_add_explicit(&monitor->tcp_packets, 1, memory_order_relaxed);
    else if (protocol == 17) atomic_fetch_add_explicit(&monitor->udp_packets, 1, memory_order_relaxed);
    else if (protocol == 1 || protocol == 58) atomic_fetch_add_explicit(&monitor->icmp_packets, 1, memory_order_relaxed);
    if (syn) atomic_fetch_add_explicit(&monitor->syn_packets, 1, memory_order_relaxed);
    if (dropped) atomic_fetch_add_explicit(&monitor->dropped_packets, 1, memory_order_relaxed);
}

void antiddos_monitor_record_connection(antiddos_monitor_t *monitor) {
    if (monitor) atomic_fetch_add_explicit(&monitor->connections, 1, memory_order_relaxed);
}

void antiddos_monitor_set_states(antiddos_monitor_t *monitor, uint64_t blocked, uint64_t suspicious) {
    if (!monitor) return;
    atomic_store_explicit(&monitor->blocked_ips, blocked, memory_order_relaxed);
    atomic_store_explicit(&monitor->suspicious_ips, suspicious, memory_order_relaxed);
}

void antiddos_monitor_snapshot(const antiddos_monitor_t *monitor, antiddos_monitor_snapshot_t *out) {
    if (!monitor || !out) return;
    out->timestamp_sec = (uint64_t)time(NULL);
    out->packets = atomic_load_explicit(&monitor->packets, memory_order_relaxed);
    out->bytes = atomic_load_explicit(&monitor->bytes, memory_order_relaxed);
    out->tcp_packets = atomic_load_explicit(&monitor->tcp_packets, memory_order_relaxed);
    out->udp_packets = atomic_load_explicit(&monitor->udp_packets, memory_order_relaxed);
    out->icmp_packets = atomic_load_explicit(&monitor->icmp_packets, memory_order_relaxed);
    out->connections = atomic_load_explicit(&monitor->connections, memory_order_relaxed);
    out->syn_packets = atomic_load_explicit(&monitor->syn_packets, memory_order_relaxed);
    out->dropped_packets = atomic_load_explicit(&monitor->dropped_packets, memory_order_relaxed);
    out->blocked_ips = atomic_load_explicit(&monitor->blocked_ips, memory_order_relaxed);
    out->suspicious_ips = atomic_load_explicit(&monitor->suspicious_ips, memory_order_relaxed);
    struct rusage usage;
    memset(&usage, 0, sizeof(usage));
    if (getrusage(RUSAGE_SELF, &usage) == 0) {
        out->cpu_user_usec = (uint64_t)usage.ru_utime.tv_sec * 1000000ULL + (uint64_t)usage.ru_utime.tv_usec;
        out->memory_bytes = (uint64_t)usage.ru_maxrss * 1024ULL;
    }
}

void antiddos_monitor_print(FILE *out, const antiddos_monitor_snapshot_t *s) {
    if (!out || !s) return;
    fprintf(out, "{\"timestamp\":%" PRIu64 ",\"packets\":%" PRIu64 ",\"bytes\":%" PRIu64
            ",\"tcp\":%" PRIu64 ",\"udp\":%" PRIu64 ",\"icmp\":%" PRIu64
            ",\"connections\":%" PRIu64 ",\"syn\":%" PRIu64 ",\"dropped\":%" PRIu64
            ",\"blocked_ips\":%" PRIu64 ",\"suspicious_ips\":%" PRIu64 ",\"memory_bytes\":%" PRIu64 ",\"cpu_user_usec\":%" PRIu64 "}\n",
            s->timestamp_sec, s->packets, s->bytes, s->tcp_packets, s->udp_packets,
            s->icmp_packets, s->connections, s->syn_packets, s->dropped_packets,
            s->blocked_ips, s->suspicious_ips, s->memory_bytes, s->cpu_user_usec);
}
