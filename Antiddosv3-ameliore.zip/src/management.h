#ifndef ANTIDDOS_MANAGEMENT_H
#define ANTIDDOS_MANAGEMENT_H

#include <stddef.h>
#include "network.h"

typedef int (*antiddos_management_handler)(const char *command, char *response,
                                           size_t response_len, void *user);

typedef struct {
    int fd;
    char path[108];
    antiddos_management_handler handler;
    void *user;
    struct antiddos_management_client *clients;
    antiddos_network_t *network;
} antiddos_management_t;

int antiddos_management_init(antiddos_management_t *management, const char *path,
                             antiddos_management_handler handler, void *user);
int antiddos_management_poll(antiddos_management_t *management, int timeout_ms);
void antiddos_management_attach(antiddos_management_t *management, antiddos_network_t *network);
int antiddos_management_handle(antiddos_management_t *management, int fd, unsigned int events);
void antiddos_management_close(antiddos_management_t *management);

#endif
