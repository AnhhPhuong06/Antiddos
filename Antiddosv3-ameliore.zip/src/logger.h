#ifndef ANTIDDOS_LOGGER_H
#define ANTIDDOS_LOGGER_H

#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <pthread.h>
#include <time.h>

typedef enum {
    ANTIDDOS_LOG_DEBUG = 0,
    ANTIDDOS_LOG_INFO,
    ANTIDDOS_LOG_WARNING,
    ANTIDDOS_LOG_SECURITY,
    ANTIDDOS_LOG_ERROR
} antiddos_log_level_t;

typedef struct antiddos_logger {
    FILE *fp;
    char path[256];
    size_t max_bytes;
    antiddos_log_level_t min_level;
    uint32_t max_lines_per_sec;
    uint32_t lines;
    time_t window;
    pthread_mutex_t lock;
    int lock_ready;
} antiddos_logger_t;

int antiddos_logger_init(antiddos_logger_t *logger, const char *path,
                         antiddos_log_level_t min_level, uint32_t max_lines_per_sec);
void antiddos_logger_close(antiddos_logger_t *logger);
void antiddos_logger_write(antiddos_logger_t *logger, antiddos_log_level_t level,
                           const char *event, const char *fmt, ...);
void antiddos_logger_vwrite(antiddos_logger_t *logger, antiddos_log_level_t level,
                            const char *event, const char *fmt, va_list ap);

#define ANTIDDOS_LOG(L, level, event, ...) antiddos_logger_write((L), (level), (event), __VA_ARGS__)

#endif
