#ifndef ANTIDDOS_MONITOR_H
#define ANTIDDOS_MONITOR_H

#include <stdint.h>
#include <stdio.h>
#include <stdatomic.h>

typedef struct {
    uint64_t timestamp_sec;
    uint64_t packets;
    uint64_t bytes;
    uint64_t tcp_packets;
    uint64_t udp_packets;
    uint64_t icmp_packets;
    uint64_t connections;
    uint64_t syn_packets;
    uint64_t dropped_packets;
    uint64_t blocked_ips;
    uint64_t suspicious_ips;
    uint64_t memory_bytes;
    uint64_t cpu_user_usec;
} antiddos_monitor_snapshot_t;

typedef struct {
    _Atomic uint64_t packets;
    _Atomic uint64_t bytes;
    _Atomic uint64_t tcp_packets;
    _Atomic uint64_t udp_packets;
    _Atomic uint64_t icmp_packets;
    _Atomic uint64_t connections;
    _Atomic uint64_t syn_packets;
    _Atomic uint64_t dropped_packets;
    _Atomic uint64_t blocked_ips;
    _Atomic uint64_t suspicious_ips;
} antiddos_monitor_t;

void antiddos_monitor_init(antiddos_monitor_t *monitor);
void antiddos_monitor_record_packet(antiddos_monitor_t *monitor, uint8_t protocol,
                                    uint64_t bytes, int syn, int dropped);
void antiddos_monitor_record_connection(antiddos_monitor_t *monitor);
void antiddos_monitor_set_states(antiddos_monitor_t *monitor, uint64_t blocked, uint64_t suspicious);
void antiddos_monitor_snapshot(const antiddos_monitor_t *monitor, antiddos_monitor_snapshot_t *out);
void antiddos_monitor_print(FILE *out, const antiddos_monitor_snapshot_t *snapshot);

#endif
