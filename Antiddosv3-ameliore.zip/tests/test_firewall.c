#define _POSIX_C_SOURCE 200809L

#include "firewall.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int main(void)
{
    antiddos_firewall_t firewall;
    uint64_t future;

    /* Disabled mode exercises state management without requiring root or an
     * nftables table in the test environment. */
    assert(antiddos_firewall_init(&firewall, 0, "antiddos_test", "blocked4") == 0);
    assert(antiddos_firewall_count(&firewall) == 0);
    assert(antiddos_firewall_add(&firewall, "192.0.2.10", 10, 0) == 0);
    assert(antiddos_firewall_add(&firewall, "2001:db8::10", 10, 0) == 0);
    assert(antiddos_firewall_count(&firewall) == 2);

    /* Canonical duplicate addresses update a rule rather than consuming a
     * second slot. */
    assert(antiddos_firewall_add(&firewall, "192.0.2.10", 30, 1) == 0);
    assert(antiddos_firewall_count(&firewall) == 2);
    assert(antiddos_firewall_add(&firewall, "not-an-ip", 10, 0) != 0);

    assert(antiddos_firewall_remove(&firewall, "2001:0db8:0:0:0:0:0:10") == 0);
    assert(antiddos_firewall_count(&firewall) == 1);
    assert(antiddos_firewall_add(&firewall, "2001:db8::10", 10, 0) == 0);
    future = (uint64_t)time(NULL) + 60U;
    assert(antiddos_firewall_expire(&firewall, future) == 1);
    assert(antiddos_firewall_count(&firewall) == 1);
    assert(antiddos_firewall_remove(&firewall, "192.0.2.10") == 0);
    assert(antiddos_firewall_count(&firewall) == 0);
    assert(antiddos_firewall_remove(&firewall, "192.0.2.10") != 0);

    assert(antiddos_firewall_add_service(&firewall, "192.0.2.10", 1, 60) == 0);
    assert(antiddos_firewall_add_service(&firewall, "192.0.2.10", 2, 60) == 0);
    assert(antiddos_firewall_count(&firewall) == 2);
    assert(antiddos_firewall_set_trusted(&firewall, "192.0.2.10", 1) == 0);
    assert(antiddos_firewall_count(&firewall) == 0);
    assert(antiddos_firewall_set_trusted(&firewall, "192.0.2.10", 0) == 0);
    assert(antiddos_firewall_add(&firewall, "192.0.2.20", 0, 1) == 0);
    assert(antiddos_firewall_add_service(&firewall, "192.0.2.30", 1, 60) == 0);

    assert(antiddos_firewall_flush(&firewall) == 0);
    assert(antiddos_firewall_count(&firewall) == 1);
    assert(antiddos_firewall_sync(&firewall) == 0);
    antiddos_firewall_close(&firewall);
    puts("test_firewall: ok");
    return 0;
}
