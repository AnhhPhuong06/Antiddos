#!/usr/bin/env python3
"""Read-only HTTP boundary tests; no running engine or nftables required."""
import http.client
import importlib.util
import pathlib
import threading
import types
import unittest
from contextlib import closing

spec = importlib.util.spec_from_file_location("dashboard", pathlib.Path(__file__).parents[1] / "tools" / "dashboard.py")
dashboard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dashboard)


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = dashboard.DashboardServer(("127.0.0.1", 0), dashboard.Handler,
                                               types.SimpleNamespace(demo=False, socket="/nonexistent"))
        cls.thread = threading.Thread(target=cls.server.serve_forever)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join()

    def request(self, path, method="GET", headers=None):
        with closing(http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=2)) as client:
            client.request(method, path, headers=headers or {})
            response = client.getresponse()
            return response.status, dict(response.getheaders()), response.read()

    def test_assets_and_status(self):
        for path in ("/", "/app.js", "/style.css", "/api/status"):
            status, headers, data = self.request(path)
            self.assertEqual(status, 200)
            self.assertTrue(data)
            self.assertEqual(headers["Cache-Control"], "no-store")
            self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
            self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_rejects_foreign_host_and_origin(self):
        self.assertEqual(self.request("/api/status", headers={"Host": "attacker.invalid"})[0], 403)
        self.assertEqual(self.request("/api/status", headers={"Origin": "https://attacker.invalid"})[0], 403)

    def test_no_file_traversal_or_write_commands(self):
        for path in ("/../config/antiddos.conf", "/%2e%2e/README.md", "/api/blacklist"):
            self.assertEqual(self.request(path)[0], 404)
        self.assertEqual(self.request("/api/status", method="POST")[0], 405)


if __name__ == "__main__":
    unittest.main()
