#define _POSIX_C_SOURCE 200809L
#include "management.h"
#include <assert.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>

static atomic_int stop;
static int respond(const char *command, char *out, size_t len, void *unused) {
    (void)unused;
    if (strcmp(command, "stats")) return -1;
    assert(len > 60000); memset(out, 'x', 60000); out[60000] = '\n'; out[60001] = '\0'; return 0;
}
static void *serve(void *arg) {
    while (!atomic_load(&stop)) assert(antiddos_management_poll(arg, 10) == 0);
    return NULL;
}
int main(void) {
    antiddos_management_t management;
    char path[108]; const char *base = getenv("TMPDIR");
    snprintf(path, sizeof(path), "%s/control-%ld.sock", base ? base : "/tmp", (long)getpid());
    assert(antiddos_management_init(&management, path, respond, NULL) == 0);
    pthread_t thread; assert(pthread_create(&thread, NULL, serve, &management) == 0);
    int client = socket(AF_UNIX, SOCK_STREAM, 0); assert(client >= 0);
    struct sockaddr_un address = {0}; address.sun_family = AF_UNIX; strcpy(address.sun_path, path);
    assert(connect(client, (struct sockaddr *)&address, sizeof(address)) == 0);
    assert(send(client, "sta", 3, 0) == 3);
    struct timespec delay = {0, 30000000}; nanosleep(&delay, NULL);
    assert(send(client, "ts\n", 3, 0) == 3);
    size_t received = 0; char buffer[1024]; ssize_t count;
    while ((count = recv(client, buffer, sizeof(buffer), 0)) > 0) received += (size_t)count;
    assert(received == 60001); close(client);
    atomic_store(&stop, 1); pthread_join(thread, NULL); antiddos_management_close(&management);
    FILE *regular = fopen(path, "w"); assert(regular); fputs("keep", regular); fclose(regular);
    assert(antiddos_management_init(&management, path, respond, NULL) != 0);
    regular = fopen(path, "r"); assert(regular); assert(fgetc(regular) == 'k'); fclose(regular); unlink(path);
    puts("test_management: ok"); return 0;
}
