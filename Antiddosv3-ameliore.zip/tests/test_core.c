#define _POSIX_C_SOURCE 200809L

#include "detector.h"
#include "limiter.h"
#include "packet.h"
#include "reputation.h"

#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static void put16(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)(value >> 8);
    p[1] = (uint8_t)value;
}

static size_t make_udp_frame(uint8_t *frame, size_t capacity,
                             uint16_t ip_total, uint16_t udp_length)
{
    size_t length = 14U + ip_total;

    assert(capacity >= length);
    memset(frame, 0, length);
    frame[12] = 0x08;
    frame[13] = 0x00;
    frame[14] = 0x45;
    put16(frame + 16, ip_total);
    frame[22] = 64;
    frame[23] = PACKET_PROTO_UDP;
    frame[26] = 192;
    frame[27] = 0;
    frame[28] = 2;
    frame[29] = 1;
    frame[30] = 198;
    frame[31] = 51;
    frame[32] = 100;
    frame[33] = 2;
    put16(frame + 34, 12345);
    put16(frame + 36, 27015);
    put16(frame + 38, udp_length);
    return length;
}

static void test_packet_validation(void)
{
    uint8_t frame[128];
    packet_view_t view;
    size_t length;

    assert(packet_parse(NULL, 0, &view) == PACKET_ERR_ARGUMENT);
    assert(packet_parse(frame, 13, &view) == PACKET_ERR_TRUNCATED);
    memset(frame, 0, sizeof(frame));
    frame[12] = 0x88;
    frame[13] = 0xb5;
    assert(packet_parse(frame, 14, &view) == PACKET_ERR_UNSUPPORTED);

    length = make_udp_frame(frame, sizeof(frame), 31, 11);
    frame[16] = 0;
    frame[17] = 19; /* shorter than the IPv4 header */
    assert(packet_parse(frame, length, &view) == PACKET_ERR_MALFORMED);

    length = make_udp_frame(frame, sizeof(frame), 31, 11);
    assert(packet_parse(frame, length, &view) == PACKET_OK);
    assert(view.protocol == PACKET_PROTO_UDP);
    assert(view.src_port == 12345 && view.dst_port == 27015);
    assert(view.payload_len == 3);
    assert(view.addr_len == 4 && !view.ipv6 && !view.fragmented);

    /* UDP length cannot extend beyond the enclosing IPv4 packet. */
    length = make_udp_frame(frame, sizeof(frame), 31, 80);
    assert(packet_parse(frame, length, &view) == PACKET_ERR_MALFORMED);

    /* A non-first fragment is valid IP but has no trustworthy L4 header. */
    length = make_udp_frame(frame, sizeof(frame), 28, 8);
    put16(frame + 20, 1); /* fragment offset = 1 (in 8-byte units) */
    assert(packet_parse(frame, length, &view) == PACKET_OK);
    assert(view.fragmented);
    assert(view.src_port == 0 && view.dst_port == 0);

    /* IHL values below five words are malformed. */
    length = make_udp_frame(frame, sizeof(frame), 31, 11);
    frame[14] = 0x44;
    assert(packet_parse(frame, length, &view) == PACKET_ERR_MALFORMED);
}

/* Keep this independent copy of the key hash only to construct a guaranteed
 * probe collision for the cleanup regression test. */
static uint64_t service_hash(uint32_t service)
{
    limiter_key_t key;
    const uint8_t *p;
    uint64_t h = 1469598103934665603ULL;

    limiter_key_service(&key, service);
    p = (const uint8_t *)&key;
    h ^= (uint8_t)key.type;
    h *= 1099511628211ULL;
    h ^= key.len;
    h *= 1099511628211ULL;
    h ^= (uint8_t)(key.port >> 8);
    h *= 1099511628211ULL;
    h ^= (uint8_t)key.port;
    h *= 1099511628211ULL;
    for (unsigned i = 0; i < 4; ++i) {
        h ^= p[offsetof(limiter_key_t, service) + i];
        h *= 1099511628211ULL;
    }
    h ^= key.protocol;
    h *= 1099511628211ULL;
    return h;
}

static void test_limiter_burst_and_cleanup(void)
{
    limiter_t limiter;
    limiter_config_t config = { .rate = 1.0, .burst = 2.0,
                                .capacity = 8, .idle_timeout_ns = 100 };
    limiter_key_t key;
    uint32_t colliding_service = 0;
    const uint32_t first_service = 1;

    assert(limiter_init(&limiter, &config) == 0);
    limiter_key_service(&key, first_service);
    assert(limiter_allow(&limiter, &key, 2.0, 0));
    assert(!limiter_allow(&limiter, &key, 1.0, 0));
    assert(limiter_allow(&limiter, &key, 1.0, 1000000000ULL));

    for (uint32_t candidate = 2; candidate != UINT32_MAX; ++candidate) {
        if ((service_hash(candidate) % config.capacity) ==
            (service_hash(first_service) % config.capacity)) {
            colliding_service = candidate;
            break;
        }
    }
    assert(colliding_service != 0);
    limiter_key_service(&key, colliding_service);
    assert(limiter_allow(&limiter, &key, 0.0, 1000));
    limiter_key_service(&key, first_service);
    assert(limiter_allow(&limiter, &key, 0.0, 0));
    assert(limiter_cleanup(&limiter, 200) == 1);
    limiter_key_service(&key, colliding_service);
    assert(limiter_allow(&limiter, &key, 0.0, 200));
    limiter_destroy(&limiter);
}

static reputation_config_t reputation_test_config(void)
{
    reputation_config_t config;
    memset(&config, 0, sizeof(config));
    config.capacity = 16;
    config.idle_ttl_ns = 100;
    config.suspicious_threshold = 10;
    config.greylist_threshold = 20;
    config.block_threshold = 30;
    config.initial_ban_ns = 50;
    config.max_ban_ns = 200;
    config.minimum_violations = 2;
    return config;
}

static void test_reputation_expiration_and_service_isolation(void)
{
    reputation_table_t table;
    reputation_config_t config = reputation_test_config();
    reputation_key_t key_a, key_b, key_idle;
    reputation_entry_t *a, *b, *idle;
    const uint8_t address[] = { 203, 0, 113, 7 };

    assert(reputation_init(&table, &config) == 0);
    reputation_key(&key_a, 10, address, (uint8_t)sizeof(address));
    reputation_key(&key_b, 11, address, (uint8_t)sizeof(address));
    a = reputation_get(&table, &key_a, 0, true);
    b = reputation_get(&table, &key_b, 0, true);
    assert(a != NULL && b != NULL && a != b);
    reputation_observe(a, 100, true, 0);
    reputation_observe(b, 200, false, 0);
    reputation_violate(&table, a, 15, 1);
    reputation_violate(&table, a, 15, 2);
    assert(reputation_is_blocked(&table, a, 2));
    assert(!reputation_is_blocked(&table, a, 100));
    assert(a->state == REPUTATION_CLEAN);
    assert(b->state == REPUTATION_CLEAN);
    /* Refresh A's activity timestamp so cleanup can expire the independent
     * clean entries without conflating it with A's ban state. */
    reputation_observe(a, 0, false, 20);

    reputation_key(&key_idle, 12, address, (uint8_t)sizeof(address));
    idle = reputation_get(&table, &key_idle, 0, true);
    assert(idle != NULL);
    /* Clean entries from both services expire independently while A remains
     * due to its more recent activity timestamp. */
    assert(reputation_cleanup(&table, 100, 16) == 2);
    assert(reputation_size(&table) == 1);
    assert(reputation_get(&table, &key_a, 100, false) == a);
    assert(reputation_get(&table, &key_b, 100, false) == NULL);
    reputation_destroy(&table);
}

static void test_detector_aggregation(void)
{
    detector_t detector;
    detector_config_t config = { .max_services = 4, .window_ns = 1000,
                                 .pps_limit = 100, .bps_limit = 16000,
                                 .syn_limit = 100, .udp_limit = 2,
                                 .icmp_limit = 100, .suspicious_threshold = 20,
                                 .attack_threshold = 50 };
    detector_event_t event;
    detector_metric_t metric;
    uint32_t score = 0;

    assert(detector_init(&detector, &config) == 0);
    memset(&event, 0, sizeof(event));
    event.service_id = 7;
    event.protocol = PACKET_PROTO_UDP;
    event.source_len = 4;
    event.bytes = 120;
    event.new_connection = true;
    assert(detector_observe(&detector, &event, 0, &score) == DETECTOR_NORMAL);
    event.new_connection = false;
    assert(detector_observe(&detector, &event, 1, &score) == DETECTOR_NORMAL);
    assert(detector_observe(&detector, &event, 2, &score) == DETECTOR_SUSPICIOUS);
    assert(score >= config.suspicious_threshold);
    assert(detector_snapshot(&detector, 7, &metric) == 0);
    assert(metric.packets == 3 && metric.bytes == 360);
    assert(metric.udp == 3 && metric.connections == 1);
    assert(detector_snapshot(&detector, 8, &metric) != 0);

    event.source_len = 17;
    assert(detector_observe(&detector, &event, 2, &score) == DETECTOR_HIGH_RISK);
    detector_destroy(&detector);
}

int main(void)
{
    test_packet_validation();
    test_limiter_burst_and_cleanup();
    test_reputation_expiration_and_service_isolation();
    test_detector_aggregation();
    reputation_entry_t window = {0};
    for (unsigned i = 0; i < 1000; ++i) reputation_observe_packet(&window, 64, false, false, 0);
    assert(window.window_packets == 1000);
    window.window_violation = true;
    reputation_observe_packet(&window, 64, false, true, 1000000000ULL);
    assert(window.packets == 1001 && window.window_packets == 1 && window.window_syn == 1);
    assert(!window.window_violation);
    limiter_t bounded;
    limiter_config_t bounded_config = {1.0, 1.0, 2, 100};
    assert(limiter_init(&bounded, &bounded_config) == 0);
    limiter_key_t invalid = {0}; invalid.len = 255;
    assert(!limiter_allow(&bounded, &invalid, 1.0, 0));
    invalid.len = 0;
    assert(!limiter_allow(&bounded, &invalid, NAN, 0));
    limiter_destroy(&bounded);
    puts("test_core: ok");
    return 0;
}
