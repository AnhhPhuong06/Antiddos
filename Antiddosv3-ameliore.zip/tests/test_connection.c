#define _POSIX_C_SOURCE 200809L
#include "connection.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    connection_table_t table;
    connection_key_t first = {0}, second;
    first.service_id = 1; first.address_len = 4; first.address[0] = 192;
    first.src_port = 1234; first.dst_port = 443; first.protocol = 6;
    second = first; second.src_port = 1235;
    assert(connection_init(&table, 4, 100) == 0);
    assert(connection_open(&table, &first, 0) == 0);
    assert(connection_open(&table, &first, 1) == 1);
    assert(connection_open(&table, &second, 0) == 0);
    assert(connection_count(&table) == 2);
    assert(connection_count_service(&table, 1) == 2);
    assert(connection_count_ip(&table, first.address, 4, 1) == 2);
    assert(connection_touch(&table, &first, 50) == 0);
    assert(connection_cleanup(&table, 100, table.capacity) == 1);
    assert(connection_count_ip(&table, first.address, 4, 1) == 1);
    assert(connection_close(&table, &first) == 0);
    assert(connection_count_service(&table, 1) == 0);
    assert(connection_close(&table, &first) == -1);
    assert(connection_open(&table, &first, 200) == 0);
    assert(connection_open(&table, &second, 200) == 0);
    assert(connection_cleanup(&table, 1000, 1) <= 1);
    connection_cleanup(&table, 1000, table.capacity);
    assert(connection_count(&table) == 0);
    first.service_id = 99;
    assert(connection_open(&table, &first, 0) == -1);
    connection_destroy(&table);
    puts("test_connection: ok");
    return 0;
}
