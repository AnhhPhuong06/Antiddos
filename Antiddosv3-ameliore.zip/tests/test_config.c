#define _POSIX_C_SOURCE 200809L

#include "config.h"

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

static char *write_config(const char *contents)
{
    char path[1024];
    const char *tempdir = getenv("TMPDIR");
    snprintf(path, sizeof(path), "%s/antiddos-config-XXXXXX", tempdir ? tempdir : "/tmp");
    int fd = mkstemp(path);
    FILE *fp;

    assert(fd >= 0);
    fp = fdopen(fd, "w");
    assert(fp != NULL);
    assert(fputs(contents, fp) >= 0);
    assert(fclose(fp) == 0);
    return strdup(path);
}

static void test_defaults_and_valid_service(void)
{
    const char *text =
        "listen_ip=127.0.0.1\n"
        "listen_port=9000\n"
        "pps_limit=5000\n"
        "worker_threads=1\n"
        "management_socket=/tmp/antiddos-test.sock\n"
        "service=game-a\n"
        "service.listen_ip=192.0.2.10\n"
        "service.listen_port=27015\n"
        "service.protocol=udp\n"
        "service.pps_limit=1000\n"
        "service.bps_limit=1000000\n"
        "service.connection_limit=64\n";
    char *path = write_config(text);
    antiddos_config_t cfg;

    assert(antiddos_config_load(path, &cfg) == 0);
    assert(strcmp(cfg.listen_ip, "127.0.0.1") == 0);
    assert(cfg.listen_port == 9000);
    assert(cfg.pps_limit == 5000);
    assert(cfg.worker_threads == 1);
    assert(strcmp(cfg.management_socket, "/tmp/antiddos-test.sock") == 0);
    assert(cfg.service_count == 1);
    assert(strcmp(cfg.services[0].service_id, "game-a") == 0);
    assert(strcmp(cfg.services[0].listen_ip, "192.0.2.10") == 0);
    assert(cfg.services[0].listen_port == 27015);
    assert(cfg.services[0].protocol == ANTIDDOS_PROTO_UDP);
    assert(cfg.services[0].pps_limit == 1000);
    assert(cfg.services[0].connection_limit == 64);
    unlink(path);
    free(path);
}

static void test_rejects_invalid_values(void)
{
    const char *bad_port = "listen_port=70000\n";
    const char *bad_threshold = "suspicious_threshold=100\nattack_threshold=50\n";
    const char *bad_protocol = "service=bad\nservice.listen_port=1234\nservice.protocol=sctp\n";
    const char *cases[] = {bad_port, bad_threshold, bad_protocol, "capture_interface=bad\"nic\n", "worker_threads=2\n", "ip_pps_limit=0\n", "temporary_ban_seconds=0\n", "capture_batch_packets=0\n", "max_ip_entries=1\n"};

    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
        char *path = write_config(cases[i]);
        antiddos_config_t cfg;
        assert(antiddos_config_load(path, &cfg) != 0);
        unlink(path);
        free(path);
    }
}

static void test_line_length_and_defaults(void)
{
    char *path;
    antiddos_config_t cfg;
    char oversized[600];

    memset(oversized, 'x', sizeof(oversized));
    oversized[sizeof(oversized) - 1] = '\0';
    path = write_config(oversized);
    assert(antiddos_config_load(path, &cfg) != 0);
    unlink(path);
    free(path);

    antiddos_config_defaults(&cfg);
    assert(strcmp(cfg.listen_ip, "0.0.0.0") == 0);
    assert(cfg.worker_threads > 0);
    assert(cfg.max_ip_entries > 0);
    assert(antiddos_config_validate(&cfg) == 0);
}

int main(void)
{
    test_defaults_and_valid_service();
    test_rejects_invalid_values();
    test_line_length_and_defaults();
    antiddos_config_t cfg;
    antiddos_config_defaults(&cfg);
    cfg.service_count = 2;
    for (size_t i = 0; i < 2; ++i) {
        snprintf(cfg.services[i].service_id, sizeof(cfg.services[i].service_id), "game%zu", i);
        snprintf(cfg.services[i].listen_ip, sizeof(cfg.services[i].listen_ip), "192.0.2.%zu", i + 1);
        cfg.services[i].listen_port = 27015;
        cfg.services[i].protocol = ANTIDDOS_PROTO_UDP;
        cfg.services[i].pps_limit = 100;
        cfg.services[i].bps_limit = 800000;
        cfg.services[i].connection_limit = 10;
    }
    assert(antiddos_config_validate(&cfg) == 0);
    uint8_t destination[4];
    assert(inet_pton(AF_INET, "192.0.2.2", destination) == 1);
    assert(antiddos_config_match_service(&cfg, 17, 27015, destination, 4) == 2);
    assert(antiddos_config_match_service(&cfg, 6, 27015, destination, 4) == 0);
    strcpy(cfg.services[0].listen_ip, "0.0.0.0");
    assert(antiddos_config_validate(&cfg) != 0); /* overlapping profiles */
    strcpy(cfg.services[0].listen_ip, "2001:db8::1");
    strcpy(cfg.services[1].listen_ip, "2001:db8:0:0::1");
    assert(antiddos_config_validate(&cfg) != 0); /* same IPv6 address */
    puts("test_config: ok");
    return 0;
}
