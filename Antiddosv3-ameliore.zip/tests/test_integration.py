#!/usr/bin/env python3
"""Kernel/IPC tests, exclusively inside a disposable Linux network namespace."""
import argparse
import json
import os
import pathlib
import socket
import subprocess
import tempfile
import time
import threading


def wait_for(condition, timeout=4):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if condition():
                return
        except (OSError, ValueError):
            pass
        time.sleep(0.03)
    raise AssertionError("Condition did not become true")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", default="./build/antiddos")
    parser.add_argument("--config", default="config/antiddos.conf")
    args = parser.parse_args()
    if os.geteuid() != 0 or os.environ.get("ANTIDDOS_TEST_NETNS") != "1":
        parser.error("Run using: sudo unshare -n env ANTIDDOS_TEST_NETNS=1 python3 tests/test_integration.py")
    if pathlib.Path("/proc/self/ns/net").exists() and os.readlink("/proc/self/ns/net") == os.readlink("/proc/1/ns/net"):
        parser.error("Refusing to modify the host network namespace")
    nft = "/usr/sbin/nft" if pathlib.Path("/usr/sbin/nft").exists() else "/sbin/nft"
    ip = "/sbin/ip" if pathlib.Path("/sbin/ip").exists() else "/usr/sbin/ip"
    subprocess.run([ip, "link", "set", "lo", "up"], check=True)
    binary = str(pathlib.Path(args.binary).resolve())
    original = pathlib.Path(args.config).read_text()
    with tempfile.TemporaryDirectory(prefix="antiddos-integration-") as temp:
        root = pathlib.Path(temp)
        control = str(root / "control.sock")
        config = original.replace("capture_interface=\n", "capture_interface=lo\n").replace("enable_firewall=0", "enable_firewall=1")
        config = config.replace("management_socket=/run/antiddos.sock", "management_socket=" + control)
        config = config.replace("ip_pps_limit=5000", "ip_pps_limit=20").replace("rate_burst_packets=256", "rate_burst_packets=5")
        config = config.replace("max_connections_per_ip=256", "max_connections_per_ip=2")
        (root / "config").write_text(config)
        policy = subprocess.run([binary, "--print-firewall", str(root / "config")], check=True, capture_output=True).stdout
        subprocess.run([nft, "-c", "-f", "-"], input=policy, check=True)
        with (root / "engine.log").open("wb") as log:
            engine = subprocess.Popen([binary, str(root / "config")], stdout=subprocess.PIPE, stderr=log)
            def command(value, fragmented=False):
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                    client.settimeout(2); client.connect(control)
                    payload = value.encode() + b"\n"
                    if fragmented:
                        client.sendall(payload[:3]); time.sleep(0.03); client.sendall(payload[3:])
                    else:
                        client.sendall(payload)
                    result = bytearray()
                    while chunk := client.recv(4096): result.extend(chunk)
                    return result.decode()
            def counters():
                data = json.loads(subprocess.run([nft, "-j", "list", "counters", "table", "inet", "antiddos"], check=True, capture_output=True).stdout)
                return {item["counter"]["name"]: item["counter"].get("packets", 0) for item in data["nftables"] if "counter" in item}
            def has_element(set_name, address):
                result = subprocess.run([nft, "list", "set", "inet", "antiddos", set_name], capture_output=True, check=True)
                return address in result.stdout.decode()
            try:
                wait_for(lambda: pathlib.Path(control).exists() and "kernel-filter" in command("status"))
                snapshot = json.loads(command("stats json", fragmented=True))
                assert snapshot["firewall_healthy"] and not snapshot["dry_run"]
                assert [(s["protocol"], s["port"]) for s in snapshot["services"]] == [("udp", 27015), ("tcp", 443)]
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as target, socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as source:
                    target.bind(("127.0.0.1", 27015)); target.settimeout(0.15)
                    source.bind(("127.0.0.1", 0))
                    for i in range(100): source.sendto(str(i).encode(), target.getsockname())
                    received = 0
                    try:
                        while target.recv(1024): received += 1
                    except socket.timeout:
                        pass
                    assert 0 < received < 100, received
                    assert counters()["rate_dropped"] > 0
                    print(f"kernel rate limit: {received}/100 local UDP packets delivered; real drop counter increased", flush=True)
                with socket.socket(socket.AF_INET6, socket.SOCK_DGRAM) as target, socket.socket(socket.AF_INET6, socket.SOCK_DGRAM) as source:
                    target.bind(("::1", 27015)); target.settimeout(0.15); source.bind(("::1", 0))
                    for i in range(100): source.sendto(b"ipv6", target.getsockname())
                    received6 = 0
                    try:
                        while target.recv(1024): received6 += 1
                    except socket.timeout:
                        pass
                    assert 0 < received6 < 100, received6
                    subprocess.run([nft, "add", "element", "inet", "antiddos", "ban1_6", "{", "::1", "timeout", "60s", "}"], check=True)
                    source.sendto(b"ipv6-ban", target.getsockname())
                    try:
                        target.recv(1024)
                    except socket.timeout:
                        pass
                    else:
                        raise AssertionError("IPv6 scoped ban was bypassed")
                print(f"IPv6: {received6}/100 local UDP packets delivered under rate limit; scoped ban enforced", flush=True)
                subprocess.run([nft, "add", "element", "inet", "antiddos", "ban1_4", "{", "127.0.0.2", "timeout", "60s", "}"], check=True)
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as target, socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as source:
                    target.bind(("127.0.0.1", 27015)); target.settimeout(0.15); source.bind(("127.0.0.2", 0))
                    source.sendto(b"scoped-ban", target.getsockname())
                    try:
                        target.recv(1024)
                    except socket.timeout:
                        pass
                    else:
                        raise AssertionError("Scoped UDP ban was not enforced")
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server, socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
                    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    server.bind(("127.0.0.1", 443)); server.listen(); server.settimeout(1)
                    client.bind(("127.0.0.2", 0)); client.settimeout(1); client.connect(server.getsockname())
                    accepted, _ = server.accept(); accepted.close()
                print("scoped ban: UDP 27015 blocked, TCP 443 still reachable from the same IP", flush=True)
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
                    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    server.bind(("127.0.0.1", 443)); server.listen(8); server.settimeout(1)
                    clients, accepted = [], []
                    try:
                        for i in range(2):
                            client = socket.socket(); clients.append(client)
                            client.bind(("127.0.0.5", 0)); client.settimeout(1); client.connect(server.getsockname())
                            accepted.append(server.accept()[0])
                        before = counters()["rate_dropped"]
                        with socket.socket() as third:
                            third.bind(("127.0.0.5", 0)); third.settimeout(0.3)
                            try:
                                third.connect(server.getsockname())
                            except socket.timeout:
                                pass
                            else:
                                raise AssertionError("Per-IP concurrent TCP limit was bypassed")
                        assert counters()["rate_dropped"] > before
                        with socket.socket() as other:
                            other.bind(("127.0.0.6", 0)); other.settimeout(1); other.connect(server.getsockname())
                            server.accept()[0].close()
                    finally:
                        for connection in clients + accepted: connection.close()
                print("TCP connection limit: two allowed, third refused, another IP allowed", flush=True)
                assert command("blacklist add 127.0.0.3").startswith("ok")
                wait_for(lambda: has_element("blocked", "127.0.0.3"))
                element_text = subprocess.run([nft, "list", "set", "inet", "antiddos", "blocked"], check=True, capture_output=True).stdout.decode()
                assert "expires" not in element_text and "timeout 60s" not in element_text
                assert command("whitelist add 127.0.0.3").startswith("ok")
                wait_for(lambda: has_element("trusted", "127.0.0.3") and not has_element("blocked", "127.0.0.3"))
                assert command("blacklist remove 127.0.0.3").startswith("ok")
                wait_for(lambda: has_element("trusted", "127.0.0.3"))
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as target, socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as source:
                    target.bind(("127.0.0.1", 27015)); target.settimeout(1); source.bind(("127.0.0.3", 0))
                    before = counters()["rate_dropped"]
                    for i in range(100): source.sendto(b"trusted", target.getsockname())
                    for i in range(100): assert target.recv(1024) == b"trusted"
                    assert counters()["rate_dropped"] == before
                print("manual blacklist has no default TTL; whitelist removes it and bypasses this tool's limits", flush=True)
                stop = threading.Event()
                def traffic():
                    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as source:
                        source.bind(("127.0.0.4", 0))
                        while not stop.is_set():
                            source.sendto(b"local-test", ("127.0.0.1", 27015)); time.sleep(0.0005)
                sender = threading.Thread(target=traffic); sender.start()
                latencies = []
                try:
                    deadline = time.monotonic() + 1.5
                    while time.monotonic() < deadline:
                        started = time.monotonic()
                        live = json.loads(command("stats json"))
                        latencies.append(time.monotonic() - started)
                        assert live["firewall_healthy"]
                        time.sleep(0.04)
                    wait_for(lambda: has_element("ban1_4", "127.0.0.4"))
                    assert not has_element("ban2_4", "127.0.0.4")
                    assert max(latencies) < 1.0, latencies
                finally:
                    stop.set(); sender.join(timeout=2)
                print(f"automatic scoped ban after sustained per-IP excess; management responded in <= {max(latencies)*1000:.1f} ms during local traffic", flush=True)
                (pathlib.Path(args.binary).resolve().parent / "integration-snapshot.json").write_text(command("stats json"))
                print("test_integration: ok", flush=True)
            finally:
                engine.terminate()
                try:
                    result = engine.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    engine.kill(); engine.wait(); raise
                if result:
                    print((root / "engine.log").read_text())
                assert result == 0, result


if __name__ == "__main__":
    main()
