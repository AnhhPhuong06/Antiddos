#!/bin/sh
set -eu
if [ "$(id -u)" != 0 ]; then
    echo "Run this installer as root on the Linux server." >&2
    exit 1
fi
./antiddos --check-config config/antiddos.conf
if [ -f /etc/antiddos/antiddos.conf ]; then
    ./antiddos --check-config /etc/antiddos/antiddos.conf
fi
install -d /etc/antiddos /usr/local/sbin
install -m 0755 antiddos /usr/local/sbin/antiddos
if [ ! -e /etc/antiddos/antiddos.conf ]; then
    install -m 0640 config/antiddos.conf /etc/antiddos/antiddos.conf
else
    echo "Existing configuration and ports preserved: /etc/antiddos/antiddos.conf"
fi
install -m 0644 systemd/antiddos.service /etc/systemd/system/antiddos.service
echo "Installed. Set capture_interface and review enable_firewall in /etc/antiddos/antiddos.conf."
echo "When ready: systemctl daemon-reload && systemctl enable --now antiddos.service"
